/* file.c */
/* Copyright (C) 2017 Pascal Urien (pascal.urien@gmail.com)
 * All rights reserved.
 *
 * BTOOLS software is free for non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution.
 * 
 * Copyright remains Pascal Urien's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Pascal Urien should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes BTOOLS software written by
 *     Pascal Urien (pascal.urien@gmail.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY PASCAL URIEN ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#ifdef WIN32
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#endif

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/timeb.h>
#include <time.h>
#include <malloc.h>

#include <openssl/ec.h>
#include <openssl/obj_mac.h> // for NID_secp256k1
#include <openssl/sha.h>
#include <openssl/ecdsa.h>
#include <openssl/ripemd.h>

#include "transaction.h"

extern int Ascii2bin(char *data_in,char *data_out);
extern int print(char *buf, int len);
extern int check_sig(char *name);

static char Locktime[4]= {(char)0,(char)0,(char)0,(char)0};
static char Thash[4]   = {(char)1,(char)0,(char)0,(char)0};
static char Sequence[4]= {(char)0xff,(char)0xff,(char)0xff,(char)0xff};

extern int bigendian;

 static char keyp[MY_MAX_INPUT][32]    ;
 static int  fscript[MY_MAX_INPUT]     ;
 static char nscript[MY_MAX_INPUT][128];

typedef	struct THEAD { 
		   char version;
           char versionpad[3];
		   char nbinput ;
                 } Thead;


typedef	struct TINPUT {
		   char txid[32];
		   char index;
		   char indexpad[3];
		   char viscript[1];
		   char sequence[4];
	                } Tinput;


typedef union SATOSHI{ unsigned char b[8] ;
                       long long l;
                     } Satoshi;


typedef	 struct TOUTPUT { unsigned char satoshi[8];
	                      unsigned char vi;
	                      unsigned char script[128];
			              int len;
	                } Toutput;


 typedef   struct PUBKEY_DER
	       {  unsigned char type;
	          unsigned char length ;
			  unsigned char ecckey[128];
			  int len;
	        }Pubkey_der ;


struct cardsig { int recover  ;
                  char r[128]   ;
			      char s[128]   ;
				  char pub[256] ;
                };

extern struct cardsig * compute_sig(char *hash, int lhash,char *name, struct cardsig  *sig, int pub_only);
 

char * Decode_BTC_Adr(char *buf);
char * DecodeWIF(char * buf);



int emptyline(char *line)
{ char line2[1024],*token;
   
  strcpy(line2,line);
 
  token = strtok(line2," \r\n"); 
  if (token == NULL)  // for example 20 20 20 CR LF returns NULL
	  return 1;

  if (*token == (char)'/')
	  return 1;

  if (*token == (char)'*')
     return 1;

	 return 0;


}


int parsefile(char *name, char *dest)
{ FILE * f = NULL ;
  char line[1024], line2[1024],*opt,*token,t[32];
  int v,nb,ni=0,no=0,i,ict=-1,oct=-1,ninput=0,k=0;
  double dv,fee;
  Satoshi sat;
 
  BIGNUM *priv_bn= NULL;
  unsigned char *pp[1]; 
  int err=0,lensig=0; 
  EC_KEY *eckey_pub=NULL     ; 
  EC_KEY *eckey_priv=NULL    ; 
  EC_POINT *pub= NULL        ;
  ECDSA_SIG *signature= NULL ;
  unsigned char *ret= NULL   ;
  EC_GROUP *ecgrp = NULL     ; 

  char hbuf[128];
  Pubkey_der pubkey_der;
  char digest[32];
  char script[26];
  int  index_script=41;
  int  len_script=26       ;
  int  last_index_script=0,nb2=0 ;
  int last_output=0;
  char *pt=NULL;

  struct cardsig mysig;
  struct cardsig *psig= NULL;
  
  BIGNUM *resu= NULL,*N=NULL,*T=NULL;

  resu = BN_new();
  N=  BN_new();
  T=  BN_new();
  err= BN_hex2bn(&N,"00FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141");

  memset(tbuf,0,sizeof(tbuf))  ;
  memset(tbuf2,0,sizeof(tbuf2));
  memset(tbuf3,0,sizeof(tbuf3));

  memset(fscript,0,sizeof(fscript));

  ((Thead *)&tbuf[0])->version = 1;

  f = fopen(name,"rt") ; 
  if (f == NULL)
  {
	  return 0;
  }


	 for(;;)
	 {
     if (fgets(line,1024,f)== NULL)  break;  // 0x0A=LF is included
	 if (line[(int)strlen(line)-1] == '\n' ) line[(int)strlen(line)-1]=0;
     if (emptyline(line)==1) continue; // comment or empty line
	 
	 strcpy(line2,line);
 
     token = strtok(line," \r\n"); 
	 if (token == NULL) continue;
     opt=token;
	
     token = strtok(NULL," \r\n");
	 // if (token == NULL) break;

	 if (strcmp(opt,"sequence") == 0)
	 { nb=  Ascii2bin(token,t)  ;
	   if (nb == 4 )  
	   { for(i=0;i<4;i++)
	     Sequence[i] = t[i];
       }
	   else
	   {   fclose(f);
		   return 0;
	   }
	 }

	 else if (strcmp(opt,"locktime") == 0)
	 { nb=  Ascii2bin(token,t)  ;
	   if (nb == 4)  
	   { for(i=0;i<4;i++)
	     Locktime[i] = t[i];
       }
	   else
	   {   fclose(f);
		   return 0;
	   }
	 }



	 else if (strcmp(opt,"nb_input") == 0)
	 { nb=sscanf(token,"%d",&v);
	   if (nb >0)  
	   { ((Thead *)&tbuf[0])->nbinput = v;
	      ninput=v;
	      no = sizeof(Thead)+ v*sizeof(Tinput) ;
       }
	   else
	   {   fclose(f);
		   return 0;
	   }
	 }

	 else if (strcmp(opt,"input") == 0)
	 { 
	 ict++;
     ni= sizeof(Thead)+ ict*sizeof(Tinput) ;
     for(i=0;i<4;i++) 
		 ((Tinput *)(tbuf+ ni))->sequence[i] = Sequence[3-i] ;
     }

     
	 else if (strcmp(opt,"transaction") == 0)
	 { nb=  Ascii2bin(token,t)  ;
	   for(i=0;i<32;i++) ((Tinput *)(tbuf+ ni))->txid[i] = t[31-i];
	 }

	 else if (strcmp(opt,"index") == 0)
	 { 
	  nb=sscanf(token,"%d",&v);
	  if (nb >0) 
		  ((Tinput*)(tbuf+ ni))->index = (char)v;
	 }

     else if (strcmp(opt,"privkey") == 0)
	 { nb=  Ascii2bin(token,keyp[ict]);
	 }
 
     else if (strcmp(opt,"wif") == 0)
	 {   pt = DecodeWIF(token);
	     if (pt != NULL)
		 nb=  Ascii2bin(pt,keyp[ict]);
	 }



     else if (strcmp(opt,"apdu_script") == 0)
	 {  strcpy(nscript[ict],token);
		fscript[ict] = 1;
	 }



	 else if (strcmp(opt,"nb_output") == 0)
	 { nb=sscanf(token,"%d",&v);
	   if (nb >0)  
	   {  tbuf[no] = (char)v; no=no+1; }
	   else
	   {   fclose(f);
		   return 0;
	   }

	 }

	 else if (strcmp(opt,"output") == 0)
	 {  
		no += last_output;
		fee= 0;

		if (token != NULL)
	    { token = strtok(line2,"\"\r\n"); 
          token = strtok(NULL,"\"\r\n") ; 
          ((Toutput *)(tbuf+no))->vi = 2 + (int)strlen(token);
		  ((Toutput *)(tbuf+no))->script[0]= (char)0x6A; //OP_RETURN
          ((Toutput *)(tbuf+no))->script[1]= (char)(0xff & strlen(token));
           memmove( &(((Toutput *)(tbuf+no))->script[2]),token,strlen(token))  ;
	      ((Toutput *)(tbuf+no))->len= 8 + 1 + (int)((Toutput *)(tbuf+no))->vi ;
		   
		   last_output =  ((Toutput *)(tbuf+no))-> len;
		   
		   oct++;
	    }
	    else
		{ oct++;
	    }
	 
     }

	 else if (strcmp(opt,"btc") == 0)
	 { nb=sscanf(token,"%lf",&dv);

       if (fee > dv)
		   printf("fee is bigger than btc, hee has been ignored\n");
	   else
		   dv = dv -fee;

	   sat.l = (long long)(dv* (double)100000000.0) ;
	   if (bigendian)
	   for(i=0;i<8;i++)
		   ((Toutput *)(tbuf+no))->satoshi[i] = sat.b[i] ;
	   else
           ((Toutput *)(tbuf+no))->satoshi[i] = sat.b[7-i] ;
   

	 }

	 else if (strcmp(opt,"fee") == 0)
	 { 
       nb=sscanf(token,"%lf",&fee);
	 }

	 else if (strcmp(opt,"hash160") == 0)
	 { nb=  Ascii2bin(token,t)  ;
	  ((Toutput *)(tbuf+no))->vi       = (char) 0x19; // 25
      ((Toutput *)(tbuf+no))->script[0]= (char) 0x76;
      ((Toutput *)(tbuf+no))->script[1]= (char) 0xa9;
      ((Toutput *)(tbuf+no))->script[2]= (char) 0x14;
      memmove(&(((Toutput *)(tbuf+no))->script[3]),t,20);
      ((Toutput *)(tbuf+no))->script[23]= (char)0x88;
      ((Toutput *)(tbuf+no))->script[24]= (char)0xac;
      ((Toutput *)(tbuf+no))->len = 8 + 1 + (int)((Toutput *)(tbuf+no))->vi;

       last_output=  8 + 1 + 25;
	 }

	 else if (strcmp(opt,"adr") == 0)
	 { pt = Decode_BTC_Adr(token);
	   if (pt != NULL)
		   nb=  Ascii2bin(pt,t) ;

	  ((Toutput *)(tbuf+no))->vi       = (char) 0x19; // 25
      ((Toutput *)(tbuf+no))->script[0]= (char) 0x76;
      ((Toutput *)(tbuf+no))->script[1]= (char) 0xa9;
      ((Toutput *)(tbuf+no))->script[2]= (char) 0x14;
      memmove(&(((Toutput *)(tbuf+no))->script[3]),t,20);
      ((Toutput *)(tbuf+no))->script[23]= (char)0x88;
      ((Toutput *)(tbuf+no))->script[24]= (char)0xac;
      ((Toutput *)(tbuf+no))->len = 8 + 1 + (int)((Toutput *)(tbuf+no))->vi;

       last_output=  8 + 1 + 25;
	 }




  
	 }

   if (f != NULL)
	   fclose(f);

   no+=  last_output ;
   
   //memmove(tbuf+no,Locktime,4);
   for(i=0;i<4;i++)
	   *(tbuf+no+i) = Locktime[3-i];
	   
   no+=4;
   memmove(tbuf+no,Thash,4);
   nb = no+4;
   printf("Raw Transaction: ");
   print(tbuf,nb);



  ecgrp = EC_GROUP_new_by_curve_name( NID_secp256k1);
  eckey_priv=EC_KEY_new();
  err= EC_KEY_set_group(eckey_priv,ecgrp);
  priv_bn = BN_new();
  eckey_pub =EC_KEY_new();
  err= EC_KEY_set_group(eckey_pub,ecgrp);
  pub = EC_POINT_new( ecgrp );
  signature = ECDSA_SIG_new();

  memmove(tbuf2,tbuf,nb);
  nb2=nb;
  last_index_script= 5+36; // => vi=0

 for (k=0;k<ninput;k++)
 { ni = sizeof(Thead)+ k*sizeof(Tinput) ; // => Input(k)

   if (!fscript[k])
   {
   hbuf[0]=0;
   for(i=0;i<32;i++) sprintf(hbuf+strlen(hbuf),"%02X",0xff & keyp[k][i]);
   
   BN_hex2bn(&priv_bn, hbuf);
   err = EC_KEY_set_private_key(eckey_priv,priv_bn);
   EC_POINT_mul( ecgrp, pub, priv_bn, NULL, NULL, NULL );
   ret = EC_POINT_point2hex( ecgrp, pub, POINT_CONVERSION_UNCOMPRESSED, NULL);
   printf( "Public Key (input %d): %s\n",k,ret);
   err= EC_KEY_set_public_key(eckey_pub,pub);
   }

   else
   { printf("\n");
	 psig = compute_sig(NULL,0,nscript[k], &mysig, 1);
     pub = EC_POINT_hex2point(ecgrp,psig->pub,pub, NULL);
     ret = EC_POINT_point2hex( ecgrp, pub, POINT_CONVERSION_UNCOMPRESSED, NULL);
     printf( "Public Key (input %d): %s\n",k,ret);
     err= EC_KEY_set_public_key(eckey_pub,pub);
   }

   pubkey_der.type   = (char)0x01;
   err = Ascii2bin(ret,pubkey_der.ecckey);
   free(ret);
   pubkey_der.length = err  ;
   pubkey_der.len= (int)pubkey_der.length + 2;

   SHA256(pubkey_der.ecckey,err,digest) ;
   RIPEMD160(digest,32,digest) ;

   script[0]=  0x19;
   script[1]=  0x76;
   script[2]=  0xa9;
   script[3]=  0x14;
   memmove(&script[4],digest,20);
   script[24]=  0x88;
   script[25]=  0xac;
   printf("Script (input %d: ",k);
   print(script,26);
   len_script=26  ;

   index_script = ni + 36   ; // => vi=0
   memmove(tbuf3,tbuf, nb)  ;
 
   memmove(tbuf3,tbuf,index_script);
   memmove(tbuf3+index_script,script,len_script);
   memmove(tbuf3+index_script+len_script,tbuf+index_script+1,nb-index_script-1);
   
   // print(tbuf3,nb+len_script-1);
   
   SHA256(tbuf3,nb+len_script-1,digest) ;
   SHA256(digest,32,digest);

   if (!fscript[k])
   signature = ECDSA_do_sign(digest,32,eckey_priv);
   
   else
   {  psig = compute_sig(digest,32,nscript[k],&mysig,0);
      if (psig == NULL) 
	  { ECDSA_SIG_free(signature) ;
	    signature = NULL;
	  }
      else
	  { err= BN_hex2bn(&signature->r, psig->r); 
        err= BN_hex2bn(&signature->s, psig->s); 
      }
    }
   
    err= BN_usub(T,N,signature->s);
    err= BN_ucmp(T,signature->s); // T >=S

    if (err >= 0) 
	   printf ("The signature is canonical\n");
	else
	{   printf ("The signature is non canonical...swapping (T,S)\n");
	    BN_swap(T,signature->s);
	}

   pp[0]= hbuf ;
   lensig= err= i2d_ECDSA_SIG(signature,pp);
   printf("Signature (input %d): ",k);
   print(hbuf,err);


   //memmove(tbuf2,tbuf,last_index_script);
   tbuf2[last_index_script]        = 1 + lensig + pubkey_der.len ;
   tbuf2[last_index_script+1]      = 1 + lensig  ;
   memmove(tbuf2+last_index_script+2,hbuf,lensig);
   memmove(tbuf2+last_index_script+2+lensig,&pubkey_der,pubkey_der.len);
   memmove(tbuf2+last_index_script+2+lensig+pubkey_der.len,
	       tbuf+index_script+1,
		   nb-index_script-1);
  
   nb2= nb2 -1 + 2+lensig+pubkey_der.len;
   last_index_script += sizeof (Tinput) -1 + 2 + lensig + pubkey_der.len ;

  // print(tbuf2,nb2);


 }

  ECDSA_SIG_free(signature) ;
  EC_GROUP_free(ecgrp)      ; 
  EC_POINT_free(pub)        ;
  EC_KEY_free(eckey_priv);
  EC_KEY_free(eckey_pub);
  BN_free(priv_bn);

  printf("Transaction: "); 
  print(tbuf2,nb2);

  f= fopen(dest,"w+b");
  if (f == NULL)
		return 0;
	fwrite(tbuf2,1,(size_t)nb2-4,f);
	fclose(f);
  
    check_sig(dest);

	return 0;
}

