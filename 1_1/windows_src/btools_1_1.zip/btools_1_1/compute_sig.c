/* compute_sig.c */
/* Copyright (C) 2017 Pascal Urien (pascal.urien@gmail.com)
 * All rights reserved.
 *
 * BTOOLS software is free for non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution.
 * 
 * Copyright remains Pascal Urien's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Pascal Urien should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes BTOOLS software written by
 *     Pascal Urien (pascal.urien@gmail.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY PASCAL URIEN ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */



#ifdef WIN32
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#endif

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/timeb.h>
#include <time.h>
#include <malloc.h>

#include "card.h" 

extern int Ascii2bin2(char *data_in,char *data_out);
extern int print(char *buf, int len);

struct cardsig { int recover  ;
                  char r[128]   ;
			      char s[128]   ;
				  char pub[256] ;
                };



static int emptyline(char *line)
{ char line2[1024],*token;
   
  strcpy(line2,line);
 
  token = strtok(line2," \r\n"); 
  if (token == NULL)  // for example 20 20 20 CR LF returns NULL
	  return 1;

  if (*token == (char)'/')
	  return 1;

  if (*token == (char)'*')
     return 1;

	 return 0;


}

struct cardsig * compute_sig(char *hash, int lhash,char *name, struct cardsig  *sig, int pub_only);

int testapdu()
{ struct cardsig sig;
  struct cardsig *ptr;
  char digest[32];
  int nb;

  do_verbose=1;

  nb = Ascii2bin2("be45cb2605bf36bebde684841a28f0fd43c69850a3dce5fedba69928ee3a8991",digest);

  ptr= compute_sig(digest,nb,"sapdu.txt",&sig,0);

  return 0;
  
}

struct cardsig * compute_sig(char *hash, int lhash,char *name, struct cardsig  *sig, int pub_only)
{ FILE *f=NULL,*fbuf=NULL;
  char line[1024], line2[1024],*opt,*token;
  int nb,ir=0,err=0,lreq,lresp,off=5,hnext=0,off_sig=2,lseq,lr,ls,i,mycard=-1,off_pub=3,pnext=0,ferror=1,adrf=0,snext=0,off_size=4;
  char req[260],resp[260];
  char more[]= { (char)0x00,(char)0xC0,(char)0x00,(char)0x00,(char)0x00};
  int maxsize=1024*3;
  char *pbuf  = NULL,*pt=NULL;
  int ftest=0;

  do_verbose=0;
  
  nb = DetectAllCard(NULL);

  if (nb <= 0)
  { printf("No smartcard reader detected!!!\n");
    return NULL;
  }
  

  printf ("Opening the APDU script %s\n\n",name);

  f = fopen(name,"rt") ; 
  if (f == NULL)
  {   printf("Unable to open file %s\n",name);
	  return NULL ;
  }

 


	 for(;;)
	 {
     if (fgets(line,1024,f)== NULL)  break;  // 0x0A=LF is included
	 if (line[(int)strlen(line)-1] == '\n' ) line[(int)strlen(line)-1]=0;
     if (emptyline(line)==1) continue; // comment or empty line
	 
	 strcpy(line2,line);
 
     token = strtok(line," \r\n"); 
	 if (token == NULL) continue ;
     opt=token;
	
     token = strtok(NULL," \r\n");
	 // if (token == NULL) break;

     
     if (strcmp(opt,"start") == 0)
	 { if (token != NULL)
	     strcpy(line,line2);
	   err= StartFirstCard(0,token) ;
	   if (err < 0)
		   break;
	   mycard= err;
  	 }

     else if (strcmp(opt,"verbose") == 0)
	 { if (token != NULL)
	   sscanf(token,"%d",&do_verbose);
  	 }
     
	 else if (strcmp(opt,"test") == 0)
	 { if (token != NULL)
	   sscanf(token,"%d",&ftest);
	   else
		   ftest=1;
  	 }



	 else if (strcmp(opt,"apdu") == 0)
	 { if (token != NULL)
	   { strcpy(line,line2);
	     lreq= Ascii2bin2(token,req);
		 if (lreq <=0) 
			 break;

         if (hnext)
		 { memmove(req+off+lhash,req+off,lreq-off);
		   memmove(req+off,hash,lhash);
		   lreq += lhash;
		 }

	     lresp = send_apdu(0,req,0,lreq,resp,0);
         if (lresp < 2)
			 break;

         if ( (lresp == 2) &&  (resp[0] == (char)0x61) )
		 { more[4]= resp[1];
		   lresp = send_apdu(0,more,0,5,resp,0);
           if (lresp <  2)
			 break;
		 }

         if ( (lresp == 2) &&  (resp[0] == (char)0x6C) )
		 { req[4]= resp[1];
		   lresp = send_apdu(0,req,0,lreq,resp,0);
           if (lresp < 2)
			 break;
		 }

		 if (!ftest &&  (resp[lresp-2] != (char)0x90) && (resp[lresp-1] != (char)0x00) ) 
			 break;


		 if (snext)
		 {
	     maxsize = (0xFF00 & (resp[off_size]<<8)) | (0xFF & resp[off_size+1]);
		 snext=0;
		 }

         if (hnext)
		 { hnext=0;
		   
           lseq = 0xFF & resp[off_sig+1]; // 30 xx
		   lr   = 0xFF & resp[off_sig+3]; // 02 xx
           ls   = 0xFF & resp[off_sig+5+lr]; // 02 xx

		   if (lseq != (lr + ls + 4) )
			   break;

		   sig->r[0]=0;
		   for(i=0;i<lr;i++)
			   sprintf(&sig->r[strlen(sig->r)],"%02X",0xff & resp[off_sig+4+i]);
		   
		   sig->s[0]=0;
		   for(i=0;i<ls;i++)
			   sprintf(&sig->s[strlen(sig->s)],"%02X",0xff & resp[off_sig+6+i+lr]);

		   ferror=0;
		   
		 }

		 else if (pnext)
		 { strcpy(sig->pub,"04");
		   for(i=0;i<64;i++)
			   sprintf(&sig->pub[strlen(sig->pub)],"%02X",0xff & resp[off_pub+i]);
		   pnext=0;
		   if (pub_only)
		   {   ferror=0;
		       break;
		   }
		 }

	   }
  	 }


	 else if (strcmp(opt,"hash") == 0)
	 { if (token != NULL)
	   {
	     err= sscanf(token,"%d",&off);
	     hnext=1;
	   }
	 }

	 else if ( (strcmp(opt,"signature") == 0) && !pub_only )
	 { if (token != NULL)
	   {
	   err= sscanf(token,"%d",&off_sig);
	   hnext=1;
	   }
	 }

	 else if (strcmp(opt,"pub") == 0)
	 { if (token != NULL)
	   { err= sscanf(token,"%d",&off_pub);
	     pnext=1;
	   }
	 }

	 else if (strcmp(opt,"maxsize") == 0)
	 { if (token != NULL)
	   { err= sscanf(token,"%d",&maxsize);
	   }
	 }

	 else if (strcmp(opt,"scsize") == 0)
	 { if (token != NULL)
	   {
	     err= sscanf(token,"%d",&off_size);
	     snext=1;
	   }
	 }


	 else if (strcmp(opt,"scwrite") == 0)
	 { if (token != NULL)
	  {  fbuf= fopen(token,"rb");
	     if (fbuf != NULL)
		 { pbuf = malloc(maxsize);
		   memset(pbuf,0,maxsize);
		   nb = (int)fread(pbuf+2,1,maxsize-2,fbuf);
		   fclose(fbuf);
		   pbuf[0]= 0xFF & nb >> 8;
           pbuf[1]= 0xFF & nb     ;
		   req[0]=(char)0;req[1]=(char)0xD0;req[2]=(char)0;req[3]=(char)0;req[4]=(char)0;
		   nb = nb+2  ;
		   pt = pbuf  ;
		   adrf=0     ;

		   while(nb>0)
		   { if (nb > 255) err=255;
		     else          err=nb ;
		     req[4] = 0xFF & err    ;
			 req[2] = 0xFF & adrf>>8;
			 req[3] = 0xFF & adrf   ;
		     memmove(req+5,pt,err);
             lresp = send_apdu(0,req,0,5+err,resp,0);
             if (lresp != 2)
			 break;
		   	 if ( (resp[lresp-2] != (char)0x90)  && (resp[lresp-1] != (char)0x00) )
			 break;
			 nb   -= err;
			 pt   += err;
			 adrf += err;
		   }
		   free(pbuf);
		   pbuf=NULL ;
   
		 }
	  }
	 }

	 else if (strcmp(opt,"scread") == 0)
	 { if (token != NULL)
	  {  fbuf= fopen(token,"w+b");
	     if (fbuf != NULL)
		 {
		   req[0]=(char)0;req[1]=(char)0xB0;req[2]=(char)0;req[3]=(char)0;req[4]=(char)2;
           lresp = send_apdu(0,req,0,5,resp,0);
           if (lresp != 4)
		   break;
           if ( (resp[lresp-2] != (char)0x90)  && (resp[lresp-1] != (char)0x00) )
		   break;
		   nb = (0xFF00 & (resp[0] << 8) ) | (0xFF & resp[1]) ;
		   adrf=2     ;

		   while(nb>0)
		   { if (nb > 256) err=256;
		     else          err=nb ;
		     req[4] = 0xFF & err    ;
			 req[2] = 0xFF & adrf>>8;
			 req[3] = 0xFF & adrf   ;
		     lresp = send_apdu(0,req,0,5,resp,0);
             if (lresp != (2+err) )
			 break;
		   	 if ( (resp[lresp-2] != (char)0x90)  && (resp[lresp-1] != (char)0x00) )
			 break;
			 fwrite(resp,1,err,fbuf);
			 nb   -= err;
			 adrf += err;
		   }
		   fclose(fbuf);
		   
		 }
	  }
	 }

	 else if (strcmp(opt,"scdisplay") == 0)
	 {     
		   req[0]=(char)0;req[1]=(char)0xB0;req[2]=(char)0;req[3]=(char)0;req[4]=(char)2;
           lresp = send_apdu(0,req,0,5,resp,0);
           if (lresp != 4)
		   break;
           if ( (resp[lresp-2] != (char)0x90)  && (resp[lresp-1] != (char)0x00) )
		   break;
		   nb = (0xFF00 & (resp[0] << 8) ) | (0xFF & resp[1]) ;
		   adrf=2     ;
		   pbuf=malloc(nb+1)  ;
		   memset(pbuf,0,nb+1);

		   while(nb>0)
		   { if (nb > 256) err=256;
		     else          err=nb ;
		     req[4] = 0xFF & err    ;
			 req[2] = 0xFF & adrf>>8;
			 req[3] = 0xFF & adrf   ;
		     lresp = send_apdu(0,req,0,5,resp,0);
             if (lresp != (2+err) )
			 break;
		   	 if ( (resp[lresp-2] != (char)0x90)  && (resp[lresp-1] != (char)0x00) )
			 break;
			 memmove(pbuf+adrf-2,resp,err);
			 nb   -= err;
			 adrf += err;
		   }

		   printf("BEGIN\n%s\nEND\n",pbuf);
		   free(pbuf);
		   pbuf=NULL;
	
	
	 }







	}
	  
   if (pbuf != NULL)
	   free(pbuf);

   if (mycard >= 0)
	   err= CloseCard(0);

   fclose(f);
	if (ferror)
		return NULL;
	else
		return sig;
}