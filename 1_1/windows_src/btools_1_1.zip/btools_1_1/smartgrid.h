extern int NBSC     ;
extern int maxslots ;

int InitializeGrid();
int SendGridSc(int *sc, char* APDU, DWORD APDUlen, char* Response, DWORD* Rlen, int nbCard, int port);
int ConnectGridSc(int nbCard, int * sc);
int DeconnectGridSc(int nbCard, int * sc);
