 #define SIZE_TRANSACTION 16384
 #define MY_MAX_INPUT 64

 char tbuf[SIZE_TRANSACTION] ;
 char tbuf2[SIZE_TRANSACTION];
 char tbuf3[SIZE_TRANSACTION];
 
 