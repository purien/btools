/* main.c */
/* Copyright (C) 2017 Pascal Urien (pascal.urien@gmail.com)
 * All rights reserved.
 *
 * BTOOLS software is free for non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution.
 * 
 * Copyright remains Pascal Urien's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Pascal Urien should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes BTOOLS software written by
 *     Pascal Urien (pascal.urien@gmail.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY PASCAL URIEN ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */


#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef WIN32
#include <windows.h>
#elif _POSIX_C_SOURCE >= 199309L
// #include <time.h>   // for nanosleep
#else
#include <unistd.h> // for usleep
#endif


int bigendian=1;

int Ascii2bin(char *Data_In,char *data_out);
int Ascii2bin2(char *Data_In,char *data_out);

extern int amain( int argc, const unsigned char *argv[] );
//extern int bmain( int argc, const unsigned char *argv[] );

extern int Decode58(char *buf, int len, char *hex);
extern int Generate_BTC_Adr_From_Privkey(char *priv, char ID);
extern int CheckWIF(char * buf, int len);
extern int Check_BTC_Adr(char *buf, int len);
extern int check_sig(char *name);
extern int TestTransaction();
extern int create_keys(char ID) ;

extern void testt();

extern int parsefile(char *name, char *dest);

extern int DoTransaction(char *name, char *server, unsigned short port,int timeout);

extern char * EditEthAdr(char * pub);

extern int sha3_main();
extern int testsha3() ;

extern unsigned char *SHA256(const unsigned char *d, size_t n,unsigned char *md);
extern int sha3_256(char *data, int datalen, char *digest);


size_t getfsize(char *name);
 
// Test PrivateKey param= exposant de la clé privé
// 18E14A7B6A307F426A94F8114701E7C8E774E7F9A47E2C2035DB29A206321725

// Test Decodage base58 d'une clé privée (avec checksum)
// 5HueCGU8rMjxEXxiPuD5BDku4MkFqeZyd4dZ1jvhTVqvbTLvyTJ

extern int B58_to_hexa(char *buf)  ;
extern int hexa_to_B58(char *data);

//extern int main33( int argc , char * argv[] );
extern int test2t();
extern int check_ether_tx(char *name);
extern int build_eth(char *name, char *dest);

extern int Generate_BTC_Adr_From_Pubkey(char *pub, char ID);

extern char * GetEthAdr(char *priv) ;
extern char * GetEthAdr2(char *priv);
extern int create_keys_ether()     ;

extern int testapdu();

struct cardsig { int recover  ;
                  char r[128]   ;
			      char s[128]   ;
				  char pub[256] ;
                };


extern struct cardsig * compute_sig(char *hash, int lhash,char *name, struct cardsig  *sig, int pub_only);

int dump(char *name, char *dest);

int do_sha256(char *name, char *dest);
int do_sha3(char *name, char *dest);

int help()
{
    printf("usage:\n");
    printf("-bin infile outfile, ascii hexa file -> binary file\n");
    printf("-dump infile [outfile], binary file -> ascii hexa encoded file\n");
    printf("-sha256  infile [outfile], SHA56(file) -> ascii hexa encoded file\n");
    printf("-sha3    infile [outfile], SHA3(file)  -> ascii hexa encoded file\n");
	printf("-genmain, generate keys and files for bitcoin main network\n");
	printf("-gentest, generate keys and files for bitcoin testnet3 network\n");
	printf("-editmain privatekey, edit keys and files for bitcoin main network\n");
	printf("-edittest privatekey, edit keys and files for bitcoin testnet3 network\n");
	printf("-editadr  pubkey [ID], edit bitcoin address from public key and optional ID (hexa)\n");
	printf("-checkadr BTC-ADR, check a bitcoin address\n");
	printf("-checkwif WIF, check a bitcoin WIF\n");
	printf("-gentrans scriptfile transactionfile, generate a transaction file for bitcoin\n");
	printf("-checktrans transactionfile, check a transaction file for bitcoin\n");
	printf("-mainnet server [timeout(s)], start a client with a bitcoin mainnet server\n");
	printf("-testnet server [timeout(s)], start a client with a bitcoin testnet server\n");
	printf("-sendmain transaction server [timeout(s)],send a transaction to a mainnet server\n");
	printf("-sendtest transaction server [timeout(s)],send a transaction to a testnet server\n");
	printf("-decode base58string, decode in hexa a base58 string and verify the checksum\n");
	printf("-hexatob58  HexaString, encode an hexa string in a base58 string\n");
	printf("-b58tohexa  Base58String, decode a base58 string in an hexa string\n");
    printf("-geneth, generate ECDSA keys and files for ethereum network\n");
	printf("-editeth privatekey, get ethereum address for ethereum network\n");
    printf("-editethadr pubkey, edit ethereum address from public key\n");
	printf("-genethtrans scriptfile transactionfile, generate a transaction file for ethereum\n");
	printf("-checkethtrans transactionfile, check a transaction file for ethereum\n");
	printf("-script filename, run a smartcard script\n");

	return 0;
}



int main(int argc, char **argv)
{

FILE *f,*fs;
char c;
int nb,err;
char *hex= NULL,*ptr=NULL;
int iResult,timeout ;
char digest [32]    ;
struct cardsig mysig;


 
  #ifdef WIN32
   WSADATA wsaData ;
   #endif

 
//sha3_main();
//testsha3();
//test2t();

//parsefile("bscript99a.txt","btest_tx99.bin");
//build_eth("escript99a.txt","test_tx99.bin") ;

//parsefile("bscript99.txt","btest_tx99.bin");
//build_eth("escript99.txt","test_tx99.bin") ;

// testapdu();

//create_keys_ether()     ;

//        "787EC5A5313A976F7BDF9EEDAFDEFC1937AE294C3BD55386A8B9775539D81653"
//GetEthAdr("3f7f0ca7d6a3ed7183e93476952a95360b1181a9c921bcb997ffa6142c23fc65");
//GetEthAdr("b205a1e03ddf50247d8483435cd91f9c732bad281ad420061ab4310c33166276");
//GetEthAdr("4ADEFA9210D4C20FAC348E118BCF5C60E3444C46E7B6E3FF4AE76D90DDF1C276");

//check_ether_tx("test_tx.bin");

//main33(argc ,argv);

// sha3_main();
// testsha3();


  if (argc == 1)
  { help();
    return 0;
  }
 
   #ifdef WIN32
   //WSAStartup(MAKEWORD(1,1),&wsaData) ; 
   iResult = WSAStartup(MAKEWORD(2,2),&wsaData) ; 
    if (iResult != 0) {
        printf("WSAStartup failed: %d\n", iResult);
        return 0;
    }
   #endif

// Generate_BTC_Adr_From_Privkey("5cfa204ea313e2fd0dfdf8ae73b867e1f617e7bc113b117a475c1892da70f6b5",(char)0);
// Generate_BTC_Adr_From_Privkey("5cfa204ea313e2fd0dfdf8ae73b867e1f617e7bc113b117a475c1892da70f6b5",(char)0x80);
// create_keys((char)0);   // mainnet
// create_keys((char)0x6F); // testnet
// 5cfa204ea313e2fd0dfdf8ae73b867e1f617e7bc113b117a475c1892da70f6b5
// testt();

/*
parsefile(
"\\Users\\Pascal\\Documents\\Visual Studio 2005\\Projects\\binwin\\script_testnet.txt",
"\\Users\\Pascal\\Documents\\Visual Studio 2005\\Projects\\binwin\\transaction777.bin");
TestTransaction();
*/


if (strcmp(argv[1],"-bin") == 0)
{  if (argc == 4)
   {
    nb= (int)getfsize(argv[2]);
	if (nb >0)
	{
	ptr= malloc(nb);
	f =fopen(argv[2],"rb");
   
	if (f != NULL)
	{
    nb = (int)fread(ptr,1,nb,f);
	fclose(f);
	fs =fopen(argv[3],"wb+");
	
	if (fs != NULL)
	{ 
	nb= Ascii2bin2(ptr,ptr);
    fwrite(ptr,1,nb,fs)    ;
	printf("%d bytes have been written\n", nb);
    fclose(fs);
	}

	free(ptr);
	}
  }
 }
}

else if (strcmp(argv[1],"-dump") == 0)
{ if (argc == 3)
  dump(argv[2],NULL);
  else if (argc == 4)
  dump(argv[2],argv[3]);
}


else if (strcmp(argv[1],"-sha256") == 0)
{ if (argc == 3)
  do_sha256(argv[2],NULL);
  else if (argc == 4)
  do_sha256(argv[2],argv[3]);
}

else if (strcmp(argv[1],"-sha3") == 0)
{ if (argc == 3)
  do_sha3(argv[2],NULL);
  else if (argc == 4)
  do_sha3(argv[2],argv[3]);
}





else if (strcmp(argv[1],"-decode") == 0)
{ if (argc == 3)
  Decode58(argv[2],(int)strlen(argv[2]),hex);
}

// ID =00 or 6F
else if (strcmp(argv[1],"-editmain") == 0)
{ if (argc == 3)
  Generate_BTC_Adr_From_Privkey(argv[2],(char)0x00);
}

else if (strcmp(argv[1],"-edittest") == 0)
{ if (argc == 3)
  Generate_BTC_Adr_From_Privkey(argv[2],(char)0x6F);
}

else if (strcmp(argv[1],"-checkwif") == 0)
{ if (argc == 3)
  CheckWIF(argv[2],(int) strlen(argv[2]));
}

else if (strcmp(argv[1],"-checkadr") == 0)
{ if (argc == 3)
  Check_BTC_Adr(argv[2],(int) strlen(argv[2]));
}

else if (strcmp(argv[1],"-genmain") == 0)
create_keys((char)0x00); // mainnet

else if (strcmp(argv[1],"-gentest") == 0)
create_keys((char)0x6F); // testnet

else if (strcmp(argv[1],"-checktrans") == 0)
{ if (argc == 3)
  check_sig(argv[2]);
}

else if (strcmp(argv[1],"-gentrans") == 0)
{ if (argc == 4)
  parsefile(argv[2],argv[3]);
}

else if (strcmp(argv[1],"-mainnet") == 0)
{ timeout=60;
if (argc == 4)
sscanf(argv[3],"%d",&timeout);
if (argc >= 3)
DoTransaction(NULL,argv[2],(unsigned short)8333,timeout);
}

else if (strcmp(argv[1],"-testnet") == 0)
{ timeout=60;
if (argc == 4)
sscanf(argv[3],"%d",&timeout);
if (argc >= 3)
DoTransaction(NULL,argv[2],(unsigned short)18333,timeout);
}

else if (strcmp(argv[1],"-sendmain") == 0)
{ timeout=60;
if (argc == 5)
sscanf(argv[4],"%d",&timeout);
if (argc >= 4)
DoTransaction(argv[2],argv[3],(unsigned short)8333,timeout);
}

else if (strcmp(argv[1],"-sendtest") == 0)
{ timeout=60;
if (argc == 5)
sscanf(argv[4],"%d",&timeout);
if (argc >= 4)
DoTransaction(argv[2],argv[3],(unsigned short)18333,timeout);
}

else if (strcmp(argv[1],"-editadr") == 0)
{   c=0;
    if (argc == 4)
	{ sscanf(argv[3],"%x",&nb);
	  c = 0xFF & nb ;
	}
    if (argc >= 3)
	Generate_BTC_Adr_From_Pubkey(argv[2],c);
}

else if (strcmp(argv[1],"-hexatob58") == 0)
{
  if (argc == 3)
  hexa_to_B58(argv[2]);
}

else if (strcmp(argv[1],"-b58tohexa") == 0)
{
  if (argc == 3)	
  B58_to_hexa(argv[2]);
}

else if (strcmp(argv[1],"-geneth") == 0)
create_keys_ether() ;

else if (strcmp(argv[1],"-editeth") == 0)
{ if (argc == 3) 
GetEthAdr2(argv[2]);
}

else if (strcmp(argv[1],"-editethadr") == 0)
{ if (argc == 3) 
  EditEthAdr(argv[2]);
}

else if (strcmp(argv[1],"-genethtrans") == 0)
{ if (argc == 4)
  build_eth(argv[2],argv[3]);
}

else if (strcmp(argv[1],"-checkethtrans") == 0)
{ if (argc == 3)
  { err = check_ether_tx(argv[2]);
    if (err ==1)
	printf("the file %s has been successfully verified\n",argv[2]);
  }
}

else if (strcmp(argv[1],"-script") == 0)
{
if (argc == 3)
{ memset(digest,127,32);
  compute_sig(digest,32,argv[2],&mysig,0);
}
}

else
{  help();
}



// 7Wcifcgb31
// 1122334455667788112233445566778811223344556677881122334455667788
// 29tBJwUudHoKU6DCpUirPLNvq3GM2wDAgtMXJpWch2Rd

// logo.jpeg
// 7cf9a31a3406fea442540dd768710eb0248ebbf8e01852f1fa5511ecbaf26fac
// 9QrLRTLjxH8a1qqpTS6dT7s3AujLHBGRreXJtv2WSXs9
// http://www.ethertrust.com/9QrLRTLjxH8a1qqpTS6dT7s3AujLHBGRreXJtv2WSXs9.jpg





#ifdef WIN32
WSACleanup();
#endif


return 0;
}

//======================
// Usefull procedures
//======================
static int isDigit(char c)
{ if (((int)c >= (int)'0') && ((int)c<= (int)'9')) return(1);
  if (((int)c >= (int)'A') && ((int)c<= (int)'F')) return(1);
  if (((int)c >= (int)'a') && ((int)c<= (int)'f')) return(1);
  return(0);
}

int Ascii2bin(char *Data_In,char *data_out)
{  	int deb=-1,fin=-1,i,j=0,nc,iCt=0,v,len;
    char c;	
	char *data_in = NULL;
    
	len =(int) strlen(Data_In);
	if ( (len & 0x1) == 0x1) // odd
	{ data_in = malloc(2+len)   ;
	  data_in[0]= (char)'0'     ;
	  if (data_in == NULL) { *data_out=0;return(0);}
	  strcpy(data_in+1,Data_In)  ;
	  len += 1;
	}
	else
	{ data_in = malloc(1+len)   ;
	  if (data_in == NULL) { *data_out=0;return(0);}
	  strcpy(data_in,Data_In)   ;
	}

	for(i=0;i<len;i++)
	{ if      ( (deb == -1) && (isDigit(data_in[i])) )             {iCt=1;deb=i;}
      else if ( (deb != -1) && (iCt==1) && (isDigit(data_in[i])) ) {iCt=2;fin=i;}

      if (iCt == 2)
	  { c= data_in[fin+1];
	    data_in[deb+1]= data_in[fin];
		data_in[deb+2]= 0;
	    nc = sscanf(&data_in[deb],"%x",&v);
		data_in[fin+1]=c;

		v &= 0xFF;data_out[j++]= v ;
		deb=fin=-1;iCt=0;
	   }
    }

	free(data_in);

return(j);
}


int Ascii2bin2(char *Data_In,char *data_out)
{  	int deb=-1,fin=-1,i,j=0,nc,iCt=0,v,len;
    char c;	
	char *data_in = NULL;
	
	len =(int) strlen(Data_In);
    data_in = malloc(1+len)   ;
	if (data_in == NULL) { *data_out=0;return(0);}
	strcpy(data_in,Data_In)   ;

	for(i=0;i<len;i++)
	{ if      ( (deb == -1) && (isDigit(data_in[i])) )             {iCt=1;deb=i;}
      else if ( (deb != -1) && (iCt==1) && (isDigit(data_in[i])) ) {iCt=2;fin=i;}

      if (iCt == 2)
	  { c= data_in[fin+1];
	    data_in[deb+1]= data_in[fin];
		data_in[deb+2]= 0;
	    nc = sscanf(&data_in[deb],"%x",&v);
		data_in[fin+1]=c;

		v &= 0xFF;data_out[j++]= v ;
		deb=fin=-1;iCt=0;
	   }
    }

	free(data_in);

return(j);
}



int print(char *buf, int len)
{ int v,i;

  printf("Len: %d\n",len);

  for(i=0;i<len;i++)
  {  v = 0xff & buf[i];
	 printf("%02X",v);
  }
  printf("\n");

  return len;
}

size_t getfsize(char *name)
{ FILE *f= NULL;
  int nb;
  size_t  size;

f = fopen(name,"rb");

if (f == NULL)
return 0;

nb= fseek(f,0,SEEK_END); // seek to end of file
size = ftell(f);         // get current file pointer

fclose(f);
return size; 



}



int dump(char *name, char *dest)
{ int nb,i;
  char *ptr=NULL;
  FILE *f=NULL;
  if (name != NULL)
  {  nb=  (int)getfsize(name); 
     if (nb <=0) 
		 return-1;

	f = fopen(name,"rb");
    if (f == NULL)
		return -1;
    
    ptr = malloc(nb);
	nb= (int)fread (ptr,1,nb,f);
	fclose(f);
	if (dest == NULL)
	{ printf("%d bytes\n",nb);
	  for(i=0;i<nb;i++)
	  printf("%2.2X", 0xFF & (*(ptr+i)));
	  printf("\n");
	}
	else
	{ f=fopen(dest,"wb+");
	  if (f != NULL)
	  {  for(i=0;i<nb;i++)
	     fprintf(f,"%2.2X", 0xFF & (*(ptr+i)));
	     fclose(f);
	  }
	}
	free(ptr);
  }

  return nb;
}


// extern unsigned char *SHA256(const unsigned char *d, size_t n,unsigned char *md);
int do_sha256(char *name, char *dest)
{ int nb,i;
  char *ptr=NULL;
  char digest[32];
  FILE *f=NULL;
  if (name != NULL)
  {  nb=  (int)getfsize(name); 
     if (nb <=0) 
		 return-1;

	f = fopen(name,"rb");
    if (f == NULL)
		return -1;
    
    ptr = malloc(nb);
	nb= (int)fread (ptr,1,nb,f);
	fclose(f);
    SHA256(ptr,(size_t)nb,digest);


	if (dest == NULL)
	{ printf("file %s has %d bytes\nSHA256:\n",name,nb);
	  for(i=0;i<32;i++)
	  printf("%2.2X", 0xFF & digest[i]);
	  printf("\n");
	}
	else
	{ f=fopen(dest,"wb+");
	  if (f != NULL)
	  {  fwrite(digest,1,32,f);
	     fclose(f);
         printf("file %s has %d bytes\nSHA256 written to file %s\n",name,nb,dest);
	  }
	}
	free(ptr);
  }

  return nb;
}
//sha3_256(char *data, int datalen, char *digest);
int do_sha3(char *name, char *dest)
{ int nb,i;
  char *ptr=NULL;
  char digest[32];
  FILE *f=NULL;
  if (name != NULL)
  {  nb=  (int)getfsize(name); 
     if (nb <=0) 
		 return-1;

	f = fopen(name,"rb");
    if (f == NULL)
		return -1;
    
    ptr = malloc(nb);
	nb= (int)fread (ptr,1,nb,f);
	fclose(f);
    sha3_256(ptr,nb,digest);

	if (dest == NULL)
	{ printf("file %s has %d bytes\nSHA3:\n",name,nb);
	  for(i=0;i<32;i++)
	  printf("%2.2X", 0xFF & digest[i]);
	  printf("\n");
	}
	else
	{ f=fopen(dest,"wb+");
	  if (f != NULL)
	  {  fwrite(digest,1,32,f);
	     fclose(f);
         printf("file %s has %d bytes\nSHA3 written to file %s\n",name,nb,dest);
	  }
	}
	free(ptr);
  }

  return nb;
}