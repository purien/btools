/* buildeth.c */
/* Copyright (C) 2017 Pascal Urien (pascal.urien@gmail.com)
 * All rights reserved.
 *
 * BTOOLS software is free for non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution.
 * 
 * Copyright remains Pascal Urien's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Pascal Urien should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes BTOOLS software written by
 *     Pascal Urien (pascal.urien@gmail.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY PASCAL URIEN ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#ifdef WIN32
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#endif

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/timeb.h>
#include <time.h>
#include <malloc.h>

#include <openssl/ec.h>
#include <openssl/obj_mac.h> // for NID_secp256k1
#include <openssl/sha.h>
#include <openssl/ecdsa.h>
#include <openssl/ripemd.h>

#include "transaction.h"

extern int Ascii2bin(char *data_in,char *data_out);
extern int print(char *buf, int len);
extern int encode_rlp(char * val, int lenv, int string, char *buf);
extern int check_ether_tx(char *name);
extern int sha3_256(char *data, int datalen, char *digest) ;   

struct ethersig { int recover  ;
                  char r[128]  ;
			      char s[128]  ;
                };

union  LV{ unsigned char b[8]      ;
           unsigned long long v    ;
         };

extern int bigendian;

extern struct ethersig * ethereum_signature(unsigned char* hash, int lenh, char *kpriv,char *sapdu);

extern size_t getfsize(char *name);

static int emptyline(char *line)
{ char line2[1024],*token;
   
  strcpy(line2,line);
 
  token = strtok(line2," \r\n"); 
  if (token == NULL)  // for example 20 20 20 CR LF returns NULL
	  return 1;

  if (*token == (char)'/')
	  return 1;

  if (*token == (char)'*')
     return 1;

	 return 0;


}

int build_eth(char *name, char *dest)
{ FILE *f=NULL,*f1=NULL;
  char line[1024], line2[1024],*opt,*token,*ptr;
  char bin[1024] ;// data size in script
  BIGNUM  *x = NULL; //BN_new();
  char keyp[128],rec=0;
  int err,nb,index=0,ferror=0,k;
  double V=0;
  union LV  lv;
  long long v;
  char digest[32];
  struct ethersig * mysig= NULL;
  char sapdu[256];
  int fscript=0;
  
  printf ("Opening the script %s\n\n",name);

  f = fopen(name,"rt") ; 
  if (f == NULL)
  {   printf("+unable to open file %s\n",name);
	  return 0;
  }

  x = BN_new();

	 for(;;)
	 {
     if (fgets(line,1024,f)== NULL)  break;  // 0x0A=LF is included
	 if (line[(int)strlen(line)-1] == '\n' ) line[(int)strlen(line)-1]=0;
     if (emptyline(line)==1) continue; // comment or empty line
	 
	 strcpy(line2,line);
 
     token = strtok(line," \r\n"); 
	 if (token == NULL) continue;
     opt=token;
	
     token = strtok(NULL," \r\n");
	 // if (token == NULL) break;

     
     if (strcmp(opt,"privkey") == 0)
	 { strcpy(keyp,token);
	 }


	 else if (strcmp(opt,"nonce") == 0)
	 { err= BN_dec2bn(&x,token);
       err = BN_bn2bin(x,bin)     ;
       nb= BN_num_bytes(x)        ;
	   ptr= BN_bn2hex(x)          ;
	   printf("nonce: %s\n", ptr);
	   free(ptr);
       err = encode_rlp(bin,nb,1,tbuf+index);
	   if (err == 0)
	   {   printf("RLP encodin,g error...\n");
	       ferror=1;
	       break;
	   }
	   index += err;
	  
	 }

	 else if (strcmp(opt,"gasPrice") == 0 )
	 { err= BN_dec2bn(&x,token);
       err = BN_bn2bin(x,bin)     ;
       nb= BN_num_bytes(x)        ;
	   ptr= BN_bn2hex(x)          ;
	   printf("gazPrice: %s\n", ptr);
	   free(ptr);
       err = encode_rlp(bin,nb,1,tbuf+index);
	   if (err == 0)
	   {   printf("RLP encoding error...\n");
	       ferror=1;
	       break;
	   }
	   index += err;
	  
	 }

	 else if (strcmp(opt,"gasLimit") == 0)
	 { err= BN_dec2bn(&x,token);
       err = BN_bn2bin(x,bin)     ;
       nb= BN_num_bytes(x)        ;
	   ptr= BN_bn2hex(x)          ;
	   printf("gazLimit: %s\n", ptr);
	   free(ptr);
       err = encode_rlp(bin,nb,1,tbuf+index);
	   if (err == 0)
	   {   printf("RLP encoding error...\n");
	       ferror=1;
	       break;
	   }
	   index += err;
	  
	 }

	 else if (strcmp(opt,"to") == 0)
	 { err= BN_hex2bn(&x,token)   ;
       err = BN_bn2bin(x,bin)     ;
       nb= BN_num_bytes(x)        ;
	   ptr= BN_bn2hex(x)          ;
	   printf("to: %s\n", ptr);   
	   free(ptr);
       err = encode_rlp(bin,nb,1,tbuf+index);
	   if (err == 0)
	   {   printf("RLP encoding error...\n");
	       ferror=1;
	       break;
	   }
	   index += err;
	  
	 }

	 else if (strcmp(opt,"data") == 0)
	 {  
		if (token != NULL)
	    { token = strtok(line2,"\"\r\n"); 
          token = strtok(NULL,"\"\r\n") ;
		  if (token == NULL)
			  nb=0;
		  else
		  {
 		  nb = (int) strlen(token)   ;
		  printf("data: %s\n", token);  
		  }

	      err = encode_rlp(token,nb,1,tbuf+index);
	       if (err == 0)
	       {   printf("RLP encoding error...\n");
		       ferror=1;
	           break;
	       }
	       index += err;
         }

		else
		{  err = encode_rlp(NULL,0,1,tbuf+index);
		   index += err;
           printf("data: %s\n", "NULL");  
		}
	 }

	 else if ( strcmp(opt,"datab") == 0)
	 { if (token != NULL)
	   {
	   err= BN_hex2bn(&x,token)   ;
       err = BN_bn2bin(x,bin)     ;
       nb= BN_num_bytes(x)        ;
	   ptr= BN_bn2hex(x)          ;
	   printf("data: %s\n", ptr);   
	   free(ptr);
       err = encode_rlp(bin,nb,1,tbuf+index);
	   if (err == 0)
	   {   printf("RLP encoding error...\n");
	       ferror=1;
	       break;
	   }
	   index += err;
	  }

      else
	  { err = encode_rlp(NULL,0,1,tbuf+index);
	    index += err;
        printf("data: %s\n", "NULL");  
	  }
	  
	 }

     else if ( strcmp(opt,"dataf") == 0)
	 { if (token != NULL)
	   { err = (int) getfsize(token);
	     if (err >0)
		 { 	 f1 = fopen(token,"rb");
		     if (f1 != NULL)
			 { ptr= malloc(err);
			   nb = (int)fread(ptr,1,err,f1);
			   fclose(f1);
			   printf("Data: ");print(ptr,nb);
               err = encode_rlp(ptr,nb,1,tbuf+index);
			   free(ptr);
	           if (err == 0)
	           {   printf("RLP encoding error...\n");
	               ferror=1;
	               break;
	           }
	          index += err;
	         }
	       }
	     }

      else
	  { err = encode_rlp(NULL,0,1,tbuf+index);
	    index += err;
        printf("data: %s\n", "NULL");  
	  }
	   
	 }


	 else if ( strcmp(opt,"value") == 0) 
	 { 
	   printf("value: %s Wei",token) ;
       err= BN_dec2bn(&x,token)      ;
       err = BN_bn2bin(x,bin)        ;
       nb= BN_num_bytes(x)           ;
	   
	   lv.v= 0;
       if (bigendian)
	   for(k=0;k<nb;k++) lv.b[k]   = bin[nb-1-k] ;
	   else
	   for(k=0;k<nb;k++) lv.b[7-k] = bin[nb-1-k] ;

		v = lv.v / (long long)1000000000;
		V= (double)v;
		V = V/(double)1000000000;
	    printf(" (%lf ETH)\n", V);
       err = encode_rlp(bin,nb,1,tbuf+index);
	   if (err == 0)
	   {   printf("RLP encoding error...\n");
	       ferror=1;
	       break;
	   }
	   index += err;
	  
	 }

	 else if ( strcmp(opt,"apdu_script") == 0) 
	 { strcpy(sapdu,token);
	   fscript=1;
	 }


  
	 }


    if (ferror == 0)
	{   
	
       err = encode_rlp(tbuf,index,0,tbuf2);
	   if (err == 0)
	   {   printf("RLP encoding error...\n");
	       ferror=1;
	   }
	   nb=err;  
	   
	   printf("Raw Transaction ");
	   print(tbuf2,nb);

	   printf("\n");
       err= sha3_256(tbuf2,nb,digest) ; 
	   if (fscript)
       mysig= ethereum_signature(digest,32,keyp,sapdu);
	   else
       mysig= ethereum_signature(digest,32,keyp,NULL);

	   if (mysig != NULL)
	   {

	   rec= mysig->recover;
	   err =  encode_rlp(&rec,1,1,tbuf+index);
	   index+= err;

       err= BN_hex2bn(&x,mysig->r) ;
       err = BN_bn2bin(x,bin)      ;
       nb= BN_num_bytes(x)         ;
	   err =  encode_rlp(bin,nb,1,tbuf+index);
	   index+= err;

       err= BN_hex2bn(&x,mysig->s) ;
       err = BN_bn2bin(x,bin)      ;
       nb= BN_num_bytes(x)         ;
	   err =  encode_rlp(bin,nb,1,tbuf+index);
	   index+= err;

       err = encode_rlp(tbuf,index,0,tbuf2);
	   nb=err;  
	   
       printf("\n");
	   printf("Final Transaction ");
	   print(tbuf2,nb);
	   }
	   else
	   { printf("Signature Error\n");
	     ferror=1;
	   }


	}
	  


    if (ferror == 0)
	{   
    f = fopen(dest,"w+b");
	fwrite(tbuf2,1,nb,f);
	fclose(f);
	f=NULL   ;

	printf("\n");
    err = check_ether_tx(dest);

    if (err ==1)
		printf("the file %s has been successfully verified\n",dest);
	}

    BN_free(x);
    
	if (f != NULL)
	fclose(f);
	
	return 0;
}