/* ecc_pub.c */
/* Copyright (C) 2017 Pascal Urien (pascal.urien@gmail.com)
 * All rights reserved.
 *
 * BTOOLS software is free for non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution.
 * 
 * Copyright remains Pascal Urien's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Pascal Urien should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes BTOOLS software written by
 *     Pascal Urien (pascal.urien@gmail.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY PASCAL URIEN ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */


#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdio.h>
#include <openssl/ec.h>
#include <openssl/obj_mac.h> // for NID_secp256k1
#include <openssl/sha.h>
#include <openssl/ecdsa.h>
#include <openssl/ripemd.h>

#include "transaction.h"

extern int Ascii2bin(char *Data_In,char *data_out);

extern int print(char *buf, int len);

extern int bigendian;

struct cardsig { int recover  ;
                  char r[128]   ;
			      char s[128]   ;
				  char pub[256] ;
                };
extern struct cardsig * compute_sig(char *hash, int lhash,char *name, struct cardsig  *sig,int pub_only);

int sha256(char * buf, int len, char *digest)
{
SHA256(buf,len,digest);

return 1;

}

int check_sig(char *name);

// int EC_KEY_set_public_key(EC_KEY *key, const EC_POINT *pub);

/** Decodes a EC_POINT from a octet string
 *  \param  group  underlying EC_GROUP object
 *  \param  p      EC_POINT object
 *  \param  buf    memory buffer with the encoded ec point
 *  \param  len    length of the encoded ec point
 *  \param  ctx    BN_CTX object (optional)
 *  \return 1 on success and 0 if an error occured
 */




// OP_DUP OP_HASH160 df3bd30160e6c6145baaf2c88a8844c13a00d1d5 OP_EQUALVERIFY OP_CHECKSIG 
// 1976a914 010966776006953d5567439e5e39f86a0d273bee 88ac
// 1976a914 df3bd30160e6c6145baaf2c88a8844c13a00d1d5 88ac


// Post de base sur les transactions
// http://www.righto.com/2014/02/bitcoins-hard-way-using-raw-bitcoin.html
// transcation00.bin

// une explication claire sur les transactions avec 1 output
// https://bitcoin.stackexchange.com/questions/3374/how-to-redeem-a-basic-tx


// talk gainewille
// transaction.bin

// Exemple de transaction 1 entt�e 1 sortie
// transaction2.bin

// 3 entr�es 2 sorties transcation3.bin
// transaction3.bin

// ref 1� transaction Pascal
// http://api.qbit.ninja/transactions/382b41ae426dbc35c0283a2d717d0ec22f5a4252e15fc3ccb1fc2c751133298e?format=raw
// transaction07.bin


// https://bitcoin.stackexchange.com/questions/29554/explanation-of-what-an-op-return-transaction-looks-like
// transaction10.bin


// https://coinlogic.wordpress.com/2014/03/09/the-bitcoin-protocol-4-network-messages-1-version/
// https://github.com/Shultzi/Mybitcoin/blob/master/connection.py
// https://bitcoin.stackexchange.com/questions/50444/unable-to-send-version-message-correctly
// https://blockchain.info/ip-log
// https://en.bitcoin.it/wiki/Protocol_documentation#Message_structure

 static char  script[MY_MAX_INPUT][64];
 static  int  index_script[MY_MAX_INPUT ];
 static  int  len_script[MY_MAX_INPUT ]  ;
 static  int  index_pscript[MY_MAX_INPUT ];
 static  int  len_pscript[MY_MAX_INPUT ]  ;
 static  int   myindex[MY_MAX_INPUT];
 static char  *ptsig[MY_MAX_INPUT],lensig[MY_MAX_INPUT];
 

int check_sig(char *name)
{ FILE *f=NULL ;
  char digest[32];
  int nb=0,len1,len2,len3,lenkey,i,nboutput=0,k=0;
  char *ptkey=NULL;
  char hbuf[512];
  char fhash[4]={(char)0x1,(char)0x0,(char)0x0,(char)0x0};
  char vi0[4]={(char)0x0 };
  char *pfrag1=NULL, *pfrag2=NULL, *pfrag3=NULL,*pt=NULL;
  int lfrag1=0,lfrag2=0,lfrag3=0,nbinput=0,vi=0,index_vi=0,begino,nbraw=0;
  int nb_script=0;
  int l1,l2,l3,l4,check;
  int ok=0;

  unsigned long long vl;
  float              vd;    

  union { char b[8];
          unsigned long long l;
        } vbtc;
 
  //BIGNUM *r= NULL;
  BIGNUM *resu= NULL,*N=NULL,*T=NULL;

  unsigned char *pp[1]; 
 
  int err=0; 
  EC_KEY *eckey[MY_MAX_INPUT]   ; 
  EC_POINT *pub= NULL        ;
  ECDSA_SIG *signature= NULL ;
  unsigned char *ret= NULL;
  EC_GROUP *ecgrp = NULL; 
  
  f = fopen(name,"rb");
  if (f== NULL) return 0;
  // create group
  // pub = EC_POINT_new(ecgrp );

  // creatye eckey
  ecgrp = EC_GROUP_new_by_curve_name( NID_secp256k1);
 
  // create group
   pub = EC_POINT_new(ecgrp );


  nb = (int)fread(tbuf,1,sizeof(tbuf),f);
  fclose(f);

  SHA256(tbuf,nb,digest)  ;
  SHA256(digest,32,digest);
  //print(digest,32);

  printf ("\nChecking Transaction File %s\n",name);
  printf("TransactionId: \n");
  for(i=31;i>=0;i--) printf("%02X",0xFF & digest[i]);
  printf("\n");

  printf("Version: \n");
  for(i=3;i>=0;i--) printf("%02X",0xFF & tbuf[i]);
  printf("\n");

  nboutput= 0xff & tbuf[4];
  begino=5;
  pfrag1=tbuf2 ;
  memmove(pfrag1,tbuf,5);
  lfrag1=5;
  printf("%d inputs\n", nboutput);


  for(k=0;k<nboutput;k++)
  {
  printf("Input_TxId\n");
  for(i=31;i>=0;i--) printf("%02X",0xFF & tbuf[begino+i]);
  printf("\n");

  printf("Input_Index\n");
  for(i=3;i>=0;i--) printf("%02X",0xFF & tbuf[begino+32+i]);
  printf("\n");

  myindex[k] = tbuf[begino+32] & 0xff ;

  len1 = 0xFF & tbuf[begino+32+4]  ; // longueur script
  len2 = 0xFF & tbuf[begino+32+4+1]; // longueur signature

  l1= 0xFF & tbuf[begino+32+4+1+2]         ; // longueur sequence signature
  l2= 0xFF & tbuf[begino+32+4+1+2+2]       ; // longueur r
  l3= 0xFF & tbuf[begino+32+4+1+2+2+l2+2]  ; // longueur s
  l4= 0xFF & tbuf[begino+32+4+1+len2+1]    ; // longueur public key

  check=0;
  if (len2 == (l1+3) )
  { if (l1 == (l2+l3+4) )
   { if (len1 == (len2+l4+2) )
     check=1;printf("Input (%d) script length checked...\n",k);
   }
  }

  if (!check)
	  return 0;

  index_pscript[k]= begino+32+4  ;
  len_pscript[k]= 1+ len1        ;

  ptsig[k]  = tbuf+begino+32+4+1+1;
  lensig[k] = len2-1;
  
  len3=  0xFF & tbuf[begino+32+4+1 + len2 + 1];
  ptkey = tbuf +     begino+32+4+1 + len2 + 1 + 1;
  lenkey = len3 ;

  SHA256(ptkey,lenkey,digest) ;
  RIPEMD160(digest,32,digest) ;
  
  printf("Signature (input %d): ",k);
  print(ptsig[k],lensig[k]);
  printf("PublicKey (input %d): ",k);
  print(ptkey,lenkey);

  script[k][0]=  0x19;
  script[k][1]=  0x76;
  script[k][2]=  0xa9;
  script[k][3]=  0x14;
  memmove(&script[k][4],digest,20);
  script[k][24]=  0x88;
  script[k][25]=  0xac;

  print(script[k],26);

  hbuf[0]=0;
  for(i=0;i<lenkey;i++) sprintf(&hbuf[strlen(hbuf)],"%02X",0xFF & *(ptkey+i));

  pub = EC_POINT_hex2point(ecgrp,hbuf,pub,NULL);
  //ret = EC_POINT_point2hex( ecgrp, pub,POINT_CONVERSION_UNCOMPRESSED , NULL );
  //printf( "%s\n",ret);
  //free(ret);
 
  eckey[k]=EC_KEY_new();
  err= EC_KEY_set_group(eckey[k],ecgrp);
  err= EC_KEY_set_public_key(eckey[k],pub);


  memmove(pfrag1+lfrag1,tbuf+begino,32+4);
  lfrag1+= 32+4 ;
  index_script[k]= lfrag1;
  len_script[k]  = 26;
  memmove(pfrag1+lfrag1,vi0,1);
  lfrag1+= 1;

  memmove(pfrag1+lfrag1,tbuf+begino+32+4+1+len1, 4);
  
  printf("Sequence:\n");
  for(i=3;i>=0;i--) printf("%02X",0xFF & tbuf[begino + 32 + 4 + (1+len1) + i]);
  printf("\n");

  begino += 32 + 4 +(1+len1) + 4;
  lfrag1+= 4 ;

 } // next k (output)

  pfrag2=&tbuf2[lfrag1];lfrag2=0;
  pfrag3=&tbuf2[lfrag1];lfrag3=0;

  nbinput  = 0xFF & tbuf[begino] ; 
  nb_script= nbinput             ;
  
  index_vi = begino+1            ;
  pt = &tbuf[begino+1]           ;
 
  
  for(i=0;i<nbinput;i++)
  {printf("Output %d\n",i);

  if (bigendian)
  for(k=0;k<8;k++) vbtc.b[k]= *(pt+k);
  else
  for(k=0;k<8;k++) vbtc.b[7-k]= *(pt+k);

   vl = vbtc.l;
   vd =(float)vl / (float)100000000.0;
   
   printf("%llu (satoshi) [",vl);

   if (bigendian)
   for(k=0;k<8;k++) printf("%02X",0xff & vbtc.b[k]); 
   else
   for(k=0;k<8;k++) printf("%02X",0xff & vbtc.b[7-k]); 
	
   printf("] %f (btc)\n",vd);

	index_vi += 8;
    pt += 8      ;
    vi=      0xFF & *(pt)  ;

    if (vl != 0L)
	{ printf("To BTC-hash160: ");
	  for(k=0;k<20;k++)printf("%02X",0xff & *(1+3+pt+k));
	  printf("\n");
	}

	else
	{ printf("Lentgh of script: %d\n",vi);
	  for(k=0;k<vi;k++)printf("%02X",0xff & *(pt+1+k));
	  printf("\n");
	}

	pt    +=    (1+vi)     ;
    index_vi += (1+vi)     ;
  }

  // pt, index_vi -> locktime=00000000
  
  printf("Locktime:\n");
  for(i=3;i>=0;i--) printf("%02X",0xFF & pt[i]);
  printf("\n");



  lfrag3=nb-1-begino+1 ;
  memmove(pfrag3,&tbuf[begino],lfrag3);
  memmove(pfrag3+lfrag3,fhash,4);
  nbraw= lfrag1 + lfrag2 + lfrag3 +4;

  memmove(tbuf+nb,fhash,4);
  
  // print(pfrag1,lfrag1);
  // print(pfrag2,lfrag2);
  // print(pfrag3,lfrag3+4);

  printf("RawTransaction ");
  print(tbuf2,nbraw);

  signature = ECDSA_SIG_new();
  resu = BN_new();
  N=  BN_new();
  T=  BN_new();
  //err = Ascii2bin("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141",hbuf);
  err= BN_hex2bn(&N,"00FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141");

  for (k=0;k<nboutput;k++)
  {

   memmove(tbuf3,tbuf2,index_script[k]);
   memmove(tbuf3+index_script[k],script[k],len_script[k]);
   memmove(tbuf3+index_script[k]+len_script[k],tbuf2+index_script[k]+1,nbraw-index_script[k]-1);
   //print(tbuf3,nbraw+len_script[k]-1);
   SHA256(tbuf3,nbraw+len_script[k]-1,digest) ;
   SHA256(digest,32,digest);

   pp[0]= ptsig[k] ;
   signature= d2i_ECDSA_SIG(&signature,pp,lensig[k]);
   //printf("r: %s\n",BN_bn2hex(signature->r));
   //printf("s: %s\n",BN_bn2hex(signature->s));

   err = ECDSA_do_verify(digest,32, signature, eckey[k]);
   if (err ==1)
   { printf("Signature (%d) is OK\n", k);
     ok++;
   }
   
// N in hex, 00FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141.
// For a given signature, (R,S), the signature (R, N-S) is also valid. 
// For a signature to be fully-canonical, the smaller of these two values must be specified.
// To fully-canonicalize a signature:
// * Begin with the signature (R,S).
// * Compute N - S, call it T.
// * If S < T, then (R,S) was already fully-canonical, use it as is.
// * Otherwise, (R,T) is the fully-canonical signature. Replace S with T in the signature.
    
   
   // int BN_ucmp(BIGNUM *a, BIGNUM *b);
   // BN_cmp() returns -1 if a < b, 0 if a == b and 1 if a > b. 
   // BN_ucmp() is the same using the absolute values of a and b.


    err= BN_usub(T,N,signature->s); // T= N-S
    err= BN_ucmp(T,signature->s);   // T >= S

    if (err >=0) 
	{   printf ("The signature (%d) is canonical\n",k);
	    ok++;
	}
	else
	   printf ("The signature (%d)is non canonical\n",k);



   

  }

  if (ok == 2*nboutput)
	  printf("\nTransaction file is OK\n");
  else
	  printf("\nERRORs in transaction file\n");

 
  for(k=0;k<nboutput;k++)
  EC_KEY_free(eckey[k]);

  ECDSA_SIG_free(signature) ;
  EC_GROUP_free(ecgrp)      ; 
  EC_POINT_free(pub)        ;
  BN_free(resu);


  return 1;
}

  

unsigned char *priv2pub( const unsigned char *priv_hex,point_conversion_form_t form )
{
 
  EC_POINT *pub = NULL;
  unsigned char *ret= NULL;
  
	
  // create group
  EC_GROUP *ecgrp = EC_GROUP_new_by_curve_name( NID_secp256k1 );

  // convert priv key from hexadecimal to BIGNUM
  BIGNUM *priv_bn = BN_new();
  BN_hex2bn(&priv_bn, priv_hex);

  // compute pub key from priv key and group
  
  
  
  pub = EC_POINT_new( ecgrp );
  EC_POINT_mul( ecgrp, pub, priv_bn, NULL, NULL, NULL );

  // convert pub_key from elliptic curve coordinate to hexadecimal
  // char *EC_POINT_point2hex(const EC_GROUP *, const EC_POINT *,	point_conversion_form_t form, BN_CTX *);
  ret = EC_POINT_point2hex( ecgrp, pub, form, NULL );
  //EC_POINT *EC_POINT_hex2point(const EC_GROUP *, const char *,EC_POINT *, BN_CTX *);

  EC_GROUP_free( ecgrp ); 
  BN_free( priv_bn ); 
  EC_POINT_free( pub );

  return ret;
}

// calculates and returns the public key associated with the given private key
// - input private key is in hexadecimal
// - output public key is in raw bytes
// form = POINT_CONVERSION_[UNCOMPRESSED|COMPRESSED|HYBRID]
unsigned char *priv2pub_bytes( const unsigned char *priv_hex, 
			       point_conversion_form_t form,
			       unsigned char *ret )
{
  EC_POINT *pub =   NULL;
  EC_GROUP *ecgrp = NULL;
  size_t len;
  BIGNUM *priv_bn= NULL;
 
  // create group
  ecgrp = EC_GROUP_new_by_curve_name( NID_secp256k1 );

  // convert priv key from hexadecimal to BIGNUM
  priv_bn = BN_new();
  BN_hex2bn( &priv_bn, priv_hex );

  // compute pub key from priv key and group
  pub = EC_POINT_new( ecgrp );
  EC_POINT_mul( ecgrp, pub, priv_bn, NULL, NULL, NULL );

  // convert pub_key from elliptic curve coordinate to bytes
  //  (first call gets the appropriate length to use)
  len = EC_POINT_point2oct( ecgrp, pub, form, NULL, 0, NULL );
  EC_POINT_point2oct( ecgrp, pub, form, ret, len, NULL );

  EC_GROUP_free( ecgrp ); 
  BN_free( priv_bn );
  EC_POINT_free( pub );

  return ret;
}


char * GetPub(char *priv)
{   char *pub_hex = priv2pub( priv, POINT_CONVERSION_UNCOMPRESSED );
return pub_hex;
}

int amain( int argc, const unsigned char *argv[] )
{
  // get priv key from cmd line and compute put key
  unsigned char *pub_hex = priv2pub( argv[2], POINT_CONVERSION_UNCOMPRESSED );

  printf( "%s\n", pub_hex );

  free( pub_hex );

  return 0;
}




int p2pub(char *priv)
{
  // get priv key from cmd line and compute put key
  unsigned char *pub_hex = priv2pub(priv, POINT_CONVERSION_UNCOMPRESSED );
  printf( "%s\n", pub_hex );
  free( pub_hex );

  return 0;
}

unsigned char * GetPubKey(char *priv)
{ return priv2pub( priv, POINT_CONVERSION_UNCOMPRESSED );
}

extern int Generate_BTC_Adr_From_Privkey(char *priv, char ID);

int create_keys(char ID)
{
    int function_status = -1;
    const BIGNUM * priv= NULL;
    const EC_POINT *pub=NULL;
    char *pubs=NULL, *privs =NULL;
  	
    EC_KEY *eckey=EC_KEY_new();


    if (NULL == eckey)
    {
        printf("Failed to create new EC Key\n");
        function_status = -1;
    }
    else
    {
        EC_GROUP *ecgroup= EC_GROUP_new_by_curve_name(NID_secp256k1);
        if (NULL == ecgroup)
        {
            printf("Failed to create new EC Group\n");
            function_status = -1;
        }
        else
        {
            int set_group_status = EC_KEY_set_group(eckey,ecgroup);
            const int set_group_success = 1;
            if (set_group_success != set_group_status)
            {
                printf("Failed to set group for EC Key\n");
                function_status = -1;
            }
            else
            {
                const int gen_success = 1;
                int gen_status = EC_KEY_generate_key(eckey);
                if (gen_success != gen_status)
                {
                    printf("Failed to generate EC Key\n");
                    function_status = -1;
                }
                else
                {
                priv = EC_KEY_get0_private_key(eckey);
                pub=   EC_KEY_get0_public_key(eckey) ;
                pubs = EC_POINT_point2hex( ecgroup, pub,POINT_CONVERSION_UNCOMPRESSED , NULL );
				printf( "PublicKey: %s\n",pubs);
                free(pubs);
                privs=BN_bn2hex(priv);
				printf( "PrivateKey %02d: %s\n",strlen(privs),privs);
                Generate_BTC_Adr_From_Privkey(privs,ID);
				free(privs);
                   
                }
            }
            EC_GROUP_free(ecgroup);
        }
       
		EC_KEY_free(eckey);
      
    }

  return function_status;
}

char * GetEthAdr(char *priv);

int create_keys_ether()
{
    int function_status = -1;
    const BIGNUM * priv= NULL;
    const EC_POINT *pub=NULL;
    char *pubs=NULL, *privs =NULL;
  	
    EC_KEY *eckey=EC_KEY_new();


    if (NULL == eckey)
    {
        printf("Failed to create new EC Key\n");
        function_status = -1;
    }
    else
    {
        EC_GROUP *ecgroup= EC_GROUP_new_by_curve_name(NID_secp256k1);
        if (NULL == ecgroup)
        {
            printf("Failed to create new EC Group\n");
            function_status = -1;
        }
        else
        {
            int set_group_status = EC_KEY_set_group(eckey,ecgroup);
            const int set_group_success = 1;
            if (set_group_success != set_group_status)
            {
                printf("Failed to set group for EC Key\n");
                function_status = -1;
            }
            else
            {
                const int gen_success = 1;
                int gen_status = EC_KEY_generate_key(eckey);
                if (gen_success != gen_status)
                {
                    printf("Failed to generate EC Key\n");
                    function_status = -1;
                }
                else
                {
                priv = EC_KEY_get0_private_key(eckey);
                pub=   EC_KEY_get0_public_key(eckey) ;
                pubs = EC_POINT_point2hex( ecgroup, pub,POINT_CONVERSION_UNCOMPRESSED , NULL );
				printf( "PublicKey: %s\n",pubs);
                free(pubs);
                privs=BN_bn2hex(priv);
				printf( "PrivateKey %02d: %s\n",strlen(privs),privs);
                GetEthAdr(privs);
				free(privs);
                   
                }
            }
            EC_GROUP_free(ecgroup);
        }
       
		EC_KEY_free(eckey);
      
    }

  return function_status;
}




//int EC_GROUP_get_order(const EC_GROUP *group, BIGNUM *order, BN_CTX *ctx);

//Points can also be described in terms of their compressed coordinates. 
// For a point (x, y), for any given value for x such that the point is on the curve, 
// there will only ever be two possible values for y. 
// Therefore a point can be set using the EC_POINT_set_compressed_coordinates_GFp() 
// and EC_POINT_set_compressed_coordinates_GF2m() functions where x is the x coordinate 
// and y_bit is a value 0 or 1 to identify which of the two possible values for y should be used.
// int EC_POINT_set_compressed_coordinates_GFp(const EC_GROUP *group, EC_POINT *p,const BIGNUM *x, int y_bit, BN_CTX *ctx);



struct ethersig { int recover  ;
                  char r[128]  ;
			      char s[128]  ;
                };

struct ethersig * ethereum_signature(unsigned char* hash, int lenh, char *kpriv,char *sapdu)
{   
	static struct ethersig mysig ;
	struct cardsig mycardsig     ;
    struct cardsig *psig=NULL    ;
	
	BIGNUM  *n = BN_new();
	BIGNUM  *h = BN_new();
    BIGNUM  *x = BN_new();
	
	BIGNUM  *a = BN_new();
	BIGNUM  *b = BN_new();
	BIGNUM  *q = BN_new();
	
	BIGNUM  *r = BN_new();
	BIGNUM  *e = BN_new();

	BIGNUM  *e1 = BN_new();
    BIGNUM  *r1 = BN_new();
	BIGNUM  *T  = BN_new();

	EC_POINT *point = NULL;
    EC_POINT *rp  =   NULL; 
    const EC_POINT *G   =   NULL; 
    EC_POINT *Q   =   NULL; 
    
	EC_POINT *Pub     =   NULL;
	EC_POINT *Pub2[4] ;
    BIGNUM *Priv = BN_new();


	char bin[256];

	int rec=0,nb=0;
	char *ptr=NULL,*ptrp=NULL;

	int err=0,i=0;
    int function_status = -1;
    int set_group_status = -1;
    int set_group_success = 1;
    const int verify_success = 1;
    int verify_status=-1;
    int gen_success = -1;
    int gen_status= -1;
	int frec=0;

    ECDSA_SIG *signature=NULL;

    BN_CTX *ctx = NULL;
 


    EC_KEY *eckey=EC_KEY_new();
    EC_KEY *eckey_priv=EC_KEY_new();
   
	EC_KEY *eckey2[4]         ;
    
	ctx = BN_CTX_new();
	for(i=0;i<4;i++) 
	{ eckey2[i]=NULL;
	  Pub2[i]=NULL;
	}


    if (NULL == eckey)
    {
        printf("Failed to create new EC Key\n");
        function_status = -1;
    }
    else
    {
        const EC_GROUP *ecgroup= EC_GROUP_new_by_curve_name(NID_secp256k1);
        if (NULL == ecgroup)
        {
            printf("Failed to create new EC Group\n");
            function_status = -1;
        }
        else
        {
			
			err = EC_GROUP_get_order(ecgroup,n,NULL)   ;
            err = BN_bn2bin(n,bin) ;
            nb= BN_num_bytes(n)    ;
			//print(bin,nb)          ;

            err = EC_GROUP_get_cofactor(ecgroup,h,NULL);
            err = BN_bn2bin(h,bin) ;
            nb= BN_num_bytes(h)    ;
			//print(bin,nb)          ;

            err=EC_GROUP_get_curve_GFp(ecgroup, q, a, b, NULL);
            
			err = BN_bn2bin(a,bin) ;
            nb= BN_num_bytes(a)    ;
			//print(bin,nb)          ;

            err = BN_bn2bin(b,bin) ;
            nb= BN_num_bytes(b)    ;
			//print(bin,nb)          ;

            err = BN_bn2bin(q,bin) ;
            nb= BN_num_bytes(q)    ;
			//print(bin,nb)          ;

			

            G     = EC_POINT_new( ecgroup );
        	point = EC_POINT_new( ecgroup );
     	    rp    = EC_POINT_new( ecgroup );
    	    Q     = EC_POINT_new( ecgroup );
 	        Pub   = EC_POINT_new( ecgroup );
 	   

            G= EC_GROUP_get0_generator(ecgroup);

			ptr = EC_POINT_point2hex(ecgroup,G,POINT_CONVERSION_UNCOMPRESSED,NULL);
			// printf("G: %s\n",ptr);
			free(ptr);

            set_group_status = EC_KEY_set_group(eckey,ecgroup);
            set_group_status = EC_KEY_set_group(eckey_priv,ecgroup);
           
            if (set_group_success != set_group_status)
            {
                printf("Failed to set group for EC Key\n");
                function_status = -1;
            }
            else
            {
                if (sapdu== NULL)
				{
                err= BN_hex2bn(&Priv, kpriv);
                err = EC_KEY_set_private_key(eckey_priv,Priv);
			    err= EC_POINT_mul( ecgroup, Pub, Priv, NULL, NULL, NULL );
                ptrp = EC_POINT_point2hex( ecgroup, Pub,POINT_CONVERSION_UNCOMPRESSED , NULL );
                // Pub = EC_KEY_get0_public_key(ptrp);
				err = EC_KEY_set_public_key(eckey,Pub);
              	printf( "PublicKey: %s\n",ptrp);
                
				ptr =BN_bn2hex(Priv);
                printf( "PrivateKey %02d: %s\n",strlen(ptr),ptr);
				free(ptr);
			    }
				 
				signature = ECDSA_SIG_new();

                if (sapdu == NULL)
                signature = ECDSA_do_sign(hash, lenh, eckey_priv);

				else
				{  psig = compute_sig(hash,lenh,sapdu,&mycardsig,0);
				   if (psig == NULL) 
				   {   ECDSA_SIG_free(signature) ;
				       signature = NULL;
				   }
				   else
				   {  ptrp = psig->pub ;
                      Pub = EC_POINT_hex2point(ecgroup,ptrp, Pub, NULL);
				      err = EC_KEY_set_public_key(eckey,Pub);
              	      printf( "PublicKey: %s\n",ptrp);
					  err= BN_hex2bn(&signature->r, psig->r); 
                      err= BN_hex2bn(&signature->s, psig->s); 
               	   }

				}

                    if (NULL == signature)
                    {
                        printf("Failed to generate EC Signature\n");
                        function_status = -1;
                    }
                    else
                    {

                    err= BN_usub(T,n,signature->s);
                    err= BN_ucmp(T,signature->s); // T >=S
                    if (err >= 0) 
	                printf ("The signature is canonical\n");
	                else
	                {   printf ("The signature is non canonical...swapping (T,S)\n");
	                    BN_swap(T,signature->s);
	                }

                        verify_status = ECDSA_do_verify(hash, lenh, signature, eckey);
                       
                        if (verify_success != verify_status)
                        {
                            printf("Failed to verify EC Signature\n");
                            function_status = -1;
                        }
                        else
                        {
                            // printf("Verifed EC Signature\n");
                            function_status = 1;

                            // rec=0 to h (h=1) x = r + rec * n
							rec= -1; //0,1,2,3
 
							while(++rec <= 3)
							{
								
							x= BN_copy(x,signature->r);  //signature->x);
							if (( rec & 2) != 0 )
							err= BN_add(x,x,n);  // h=1
							
                     
						    err = BN_cmp(q,x); // -1 q<x , 0 q=x, 1 q>x
                            if (err <=0)  // x >= q
							{	printf("invalid x value\n");
							    continue;
							}

                            //Convert the octet string 02|| X to an elliptic curve point R
                            err=  EC_POINT_set_compressed_coordinates_GFp(ecgroup,point,x,rec & 1,NULL);
							ptr = EC_POINT_point2hex(ecgroup,point,POINT_CONVERSION_COMPRESSED,NULL);
							printf("R: %s\n",ptr);
							free(ptr);
                            ptr = EC_POINT_point2hex(ecgroup,point,POINT_CONVERSION_UNCOMPRESSED,NULL);
                            // printf("R: %s\n",ptr);
							free(ptr);

                            // If nR#O, then do another iteration of Step 1.

							err=  EC_POINT_mul(ecgroup,rp,NULL,point,n,NULL);

                            err = EC_POINT_is_at_infinity(ecgroup,rp);
							if (err != 1)
							{	printf("error, nR is not infinity point\n");
							    continue;
							}

						    e= BN_bin2bn(hash,lenh,e);
                            err = BN_bn2bin(e,bin) ;
                            nb= BN_num_bytes(e)    ;

			                //print(bin,nb)          ;
							//print(hash,lenh)       ;

							nb = BN_num_bits(n); //  M!
							if ( (8*lenh) > nb)  
								err= BN_rshift(e,e,(8*lenh)-nb);	
                           
							
                            r1 = BN_mod_inverse(r1,signature->r,n,ctx);
							err= BN_sub(e1,n,e); // r = a-b
							                          
        				
							// Q= r-1(sR-eG)
							err= BN_mod_mul(e1,r1,e,n,ctx);
                            err= BN_mod_mul(r1,r1,signature->s,n,ctx);

                            err=  EC_POINT_mul(ecgroup,Q,NULL,G,e1,NULL);
                            err=  EC_POINT_invert(ecgroup,Q,NULL);
                            err=  EC_POINT_mul(ecgroup,point,NULL,point,r1,NULL);
                            
							err = EC_POINT_add(ecgroup,Q,Q,point,NULL);

                            ptr = EC_POINT_point2hex( ecgroup,Q,POINT_CONVERSION_UNCOMPRESSED , NULL );
							printf("Q: %s\n",ptr);
                           
							//if (strcmp(ptr,ptrp)==0)
							//{	
								
                                Pub2[rec]  = EC_POINT_new(ecgroup);
                                Pub2[rec] =  EC_POINT_hex2point(ecgroup,ptr,Pub2[rec],NULL);
                                eckey2[rec]= EC_KEY_new();
								err= EC_KEY_set_group(eckey2[rec],ecgroup)        ;
								err= EC_KEY_set_public_key(eckey2[rec],Pub2[rec]) ;

                                verify_status = ECDSA_do_verify(hash, lenh, signature, eckey2[rec]);
                                if (verify_success == verify_status)
								{   printf("Signature Verified\n");
								    if (strcmp(ptr,ptrp)==0)
									{ printf("PublicKey Recovered, v=%d\n",27+rec)  ;
									  frec=1;
									  mysig.recover = 27+rec      ;
                                      ptr= BN_bn2hex(signature->r);
									  strcpy(mysig.r,ptr);
									  free (ptr);
                                      ptr= BN_bn2hex(signature->s);
									  strcpy(mysig.s,ptr);
									  free(ptr);

								      break;
								    }
								}


								
							//}


						 }


                        }

		             }
         }
       	
        
		 
		 // EC_GROUP_free(ecgroup);

		 for(i=0;i<4;i++)
		 { if (eckey2[i] != NULL) EC_KEY_free(eckey2[i]);
	       if (Pub2[i]   != NULL) EC_POINT_free(Pub2[i]);
		 }



        }

        EC_KEY_free(eckey);
        EC_KEY_free(eckey_priv);
        EC_POINT_free(Pub);
	    
		BN_free(Priv);

		BN_free(T);
		BN_free(n);
		BN_free(h);
        BN_free(x);
        BN_free(a);
        BN_free(b);
        BN_free(q);
   		BN_free(r);
        BN_free(e);
		BN_free(e1);
		BN_free(r1);

       ECDSA_SIG_free(signature) ;


    }

if (frec)
return &mysig ;

return NULL;
}






char * recover_signature(char *hash, int lenh, char *ir, char *is, int rec, char *kpub)
{   BIGNUM  *n = BN_new();
	BIGNUM  *h = BN_new();
    BIGNUM  *x = BN_new();
	
	BIGNUM  *a = BN_new();
	BIGNUM  *b = BN_new();
	BIGNUM  *q = BN_new();
	
	BIGNUM  *r = BN_new();
	BIGNUM  *s = BN_new();
	BIGNUM  *e = BN_new();

	BIGNUM  *e1 = BN_new();
    BIGNUM  *r1 = BN_new();

	EC_POINT *point = NULL;
    EC_POINT *rp  =   NULL; 
    const EC_POINT *G   = NULL; 
    EC_POINT *Q    =   NULL; 
    EC_POINT *Pub  =   NULL;
	
	char bin[256];

	int nb=0;
	char *ptr=NULL,*ptrp=NULL;

	int err=0,i=0;
    int function_status = -1;
    int set_group_status = -1;
    int set_group_success = 1;
    const int verify_success = 1;
    int verify_status=-1;
    int gen_success = -1;
    int gen_status= -1;
	int recover=-1    ;

    BN_CTX *ctx = NULL;
 
    EC_KEY *eckey=EC_KEY_new();
    ECDSA_SIG *signature = ECDSA_SIG_new();

    err=BN_hex2bn(&r,ir);
    err=BN_hex2bn(&s,is);

	//ptr = BN_bn2dec(r);
	//printf("r= %s\n",ptr);

	//ptr = BN_bn2dec(s);
	//printf("s= %s\n",ptr);


    signature->r= BN_copy(signature->r,r);  
    signature->s= BN_copy(signature->s,s);  

	//ptr = BN_bn2dec(signature->r);
	//printf("r= %s\n",ptr);

	//ptr = BN_bn2dec(signature->s);
	//printf("s= %s\n",ptr);


	ctx = BN_CTX_new();


    if (NULL == eckey)
    {
        printf("Failed to create new EC Key\n");
        function_status = -1;
    }
    else
    {
        const EC_GROUP *ecgroup= EC_GROUP_new_by_curve_name(NID_secp256k1);
        if (NULL == ecgroup)
        {
            printf("Failed to create new EC Group\n");
            function_status = -1;
        }
        else
        {
			err = EC_GROUP_get_order(ecgroup,n,NULL)   ;
            err = BN_bn2bin(n,bin) ;
            nb= BN_num_bytes(n)    ;
			//print(bin,nb)          ;

            err = EC_GROUP_get_cofactor(ecgroup,h,NULL);
            err = BN_bn2bin(h,bin) ;
            nb= BN_num_bytes(h)    ;
			//print(bin,nb)        ;

            err=EC_GROUP_get_curve_GFp(ecgroup, q, a, b, NULL);
            
			err = BN_bn2bin(a,bin) ;
            nb= BN_num_bytes(a)    ;
			//print(bin,nb)          ;

            err = BN_bn2bin(b,bin) ;
            nb= BN_num_bytes(b)    ;
			//print(bin,nb)          ;

            err = BN_bn2bin(q,bin) ;
            nb= BN_num_bytes(q)    ;
			//print(bin,nb)          ;


            G     = EC_POINT_new( ecgroup );
        	point = EC_POINT_new( ecgroup );
     	    rp    = EC_POINT_new( ecgroup );
    	    Q     = EC_POINT_new( ecgroup );
 	        Pub   = EC_POINT_new( ecgroup );
 	   

            G= EC_GROUP_get0_generator(ecgroup);

			//ptr = EC_POINT_point2hex(ecgroup,G,POINT_CONVERSION_UNCOMPRESSED,NULL);
			//printf("G: %s\n",ptr);


            set_group_status = EC_KEY_set_group(eckey,ecgroup);
           
            if (set_group_success != set_group_status)
            {
                printf("Failed to set group for EC Key\n");
                function_status = -1;
            }
            else
            {               
                      		x= BN_copy(x,r);  
							if (( rec & 2) != 0 )
							err= BN_add(x,x,n);  // h=1
							
                     
						    err = BN_cmp(q,x); // -1 q<x , 0 q=x, 1 q>x
                            if (err <=0)  // x >= q
							{	printf("invalid x value\n");
							}

							else
							{
                            //Convert the octet string 02|| X to an elliptic curve point R
                            err=  EC_POINT_set_compressed_coordinates_GFp(ecgroup,point,x,rec & 1,NULL);
							
							//ptr = EC_POINT_point2hex(ecgroup,point,POINT_CONVERSION_COMPRESSED,NULL);
							//printf("R: %s\n",ptr);
							//free (ptr);

                            //ptr = EC_POINT_point2hex(ecgroup,point,POINT_CONVERSION_UNCOMPRESSED,NULL);
                            //printf("R: %s\n",ptr);
							//free(ptr);

                            // If nR#O, then do another iteration of Step 1.

							err=  EC_POINT_mul(ecgroup,rp,NULL,point,n,NULL);

                            err = EC_POINT_is_at_infinity(ecgroup,rp);
							if (err != 1)
							{	printf("error, nR is not infinity point\n");
							}
							else
							{
						    e= BN_bin2bn(hash,lenh,e);
                            err = BN_bn2bin(e,bin) ;
                            nb= BN_num_bytes(e)    ;
			                //print(bin,nb)          ;
							//print(hash,lenh)       ;

							nb = BN_num_bits(n); //  M!
							if ( (8*lenh) > nb)  
								err= BN_rshift(e,e,(8*lenh)-nb);	
                           
							
                            r1 = BN_mod_inverse(r1,r,n,ctx);
							err= BN_sub(e1,n,e); // r = a-b
							                          
        				
							// Q= r-1(sR-eG)
							err= BN_mod_mul(e1,r1,e,n,ctx);
                            err= BN_mod_mul(r1,r1,s,n,ctx);

                            err=  EC_POINT_mul(ecgroup,Q,NULL,G,e1,NULL);
                            err=  EC_POINT_invert(ecgroup,Q,NULL);
                            err=  EC_POINT_mul(ecgroup,point,NULL,point,r1,NULL);
                            
							err = EC_POINT_add(ecgroup,Q,Q,point,NULL);

                            ptrp = EC_POINT_point2hex( ecgroup,Q,POINT_CONVERSION_UNCOMPRESSED , NULL );
							//printf("Q: %s\n",ptrp);
                           							
                            Pub  =  EC_POINT_new(ecgroup);
                            Pub  =  EC_POINT_hex2point(ecgroup,ptrp,Pub,NULL);
                            err= EC_KEY_set_public_key(eckey,Pub)           ;

                                verify_status = ECDSA_do_verify(hash, lenh, signature, eckey);
                                if (verify_success == verify_status)
								{   printf("Signature Verified\n");
								    recover=1;
								   
								}
                          
							}}

	         
		       
         }
       	
        
		 
		 // EC_GROUP_free(ecgroup);


        }

        EC_KEY_free(eckey);

		EC_POINT_free(point);
        EC_POINT_free(rp);
        EC_POINT_free(Q);
        EC_POINT_free(Pub);

       BN_CTX_free(ctx);

   		BN_free(n);
		BN_free(h);
        BN_free(x);
        BN_free(a);
        BN_free(b);
        BN_free(q);
   		BN_free(r);
        BN_free(s);
        BN_free(e);
		BN_free(e1);
		BN_free(r1);



    }

if (ptrp!= NULL)
{ strcpy(kpub,ptrp);
  free(ptrp);
}

  if (recover != 1)
	  return NULL;
  
  return kpub;
}




struct rlpitem { char * next   ;
                 char *data    ;
				 int len       ;
				 int lhead     ;
				 int is_string ;
                       } ;

extern struct rlpitem * decode_rlp(char *buf, int len, struct rlpitem  * RLP);
extern int encode_rlp(char * val, int lenv, int string, char *buf);

union  LV{ unsigned char b[8]    ;
           unsigned long long v  ;
         };

extern int sha3_256(char *data, int datalen, char *digest) ; 

	
int check_ether_tx(char *name)
{ //char tbuf[2048];
  //char tbuf2[2048];
  char digest[32];
  FILE *f=NULL   ;
  int nb,i,k,np ;
  struct rlpitem item[10],*ret;
  long long v; // 64 bits
  double V;
  char *ptr,*pp,*ptrs=NULL,*ptrr=NULL;
  union LV lv  ;
  int fparse=1,ferror=0,fok=0,rec=0;
 
  BIGNUM  *x = BN_new();
  BIGNUM  *r = BN_new();
  BIGNUM  *s = BN_new();

  printf("Checking Transaction File %s\n",name);

  f = fopen(name,"rb");
  if (f== NULL)
	  return 0;

  nb= (int)fread(tbuf,1,sizeof(tbuf),f);
  fclose(f);

  sha3_256(tbuf,nb,digest) ; 
  printf("TransactionId: ");print(digest,32);

  pp = tbuf;
  np = nb  ;
  for(i=0;i<=9;i++)
  {
  ret= decode_rlp(pp,np, &item[i]);
  if (ret==NULL)
  { printf("Error in file %s\n",name);
    break;
  }
 
  if (item[i].is_string)
  { pp= item[i].next     ;
    np= np - item[i].len-item[i].lhead ;
  }
  else
  { pp= item[i].data;
    np= np - item[i].lhead ;
  }

  if (np < 0)
	  printf("Length error\n");
  if (np == 0)
	  fparse=1;

   switch (i)
    {
      case 0:
		  printf("List Length: %d\n",item[i].len);
		  if ( (item[i].len + item[i].lhead) != nb )
		  { printf("List length error !!!\n");
		    i= 11;
            ferror=1;
		  }

		  break;

	  case 1:
		  if (item[i].len == 0)
		  printf("nonce: 0x");
		  else
		  {
	      x= BN_bin2bn(item[i].data,item[i].len,x);
		  ptr = BN_bn2dec(x);
	      printf("nonce: %s\n",ptr);
		  free(ptr);
		  }
		  break;
	
      case 2:
	      x= BN_bin2bn(item[i].data,item[i].len,x);
		  ptr = BN_bn2dec(x);
		  lv.v= 0 ;

		  if (bigendian)
          for(k=0;k<item[i].len;k++) 
			  lv.b[k] = item[i].data[item[i].len-1-k] ;
		  else
           for(k=0;k<item[i].len;k++) 
			  lv.b[7-k] = item[i].data[item[i].len-1-k] ;
		  v =lv.v/1000000000L;

	      printf("gasPrice: %s (%d GWei)\n",ptr,v);
		  free(ptr);
		  break; 

      case 3:
	      x= BN_bin2bn(item[i].data,item[i].len,x);
		  ptr = BN_bn2dec(x);
	      printf("gasLimit: %s\n",ptr);
		  free(ptr);
		  break; 
    
	  case 4:
	      printf("to: 0x");
		  for(k=0;k<item[i].len;k++)
			  printf("%02X", 0xFF & item[i].data[k]);
		  printf("\n");
		  if (item[i].len != 20)
		  { printf("Adress length error (length= %d)\n",item[i].len);
		    i=11;
            ferror=1;
		  }


		  break; 

      case 5:
	      //no= BN_num_bytes(x) ;
		  lv.v= 0 ;

		  if (bigendian)
          for(k=0;k<item[i].len;k++)
	      lv.b[k] = item[i].data[item[i].len-1-k] ;
		  else
          for(k=0;k<item[i].len;k++)
	      lv.b[7-k] = item[i].data[item[i].len-1-k] ;

		  v = lv.v / (long long)1000000000;
		  V= (double)v;
		  V = V/(double)1000000000;
	      x= BN_bin2bn(item[i].data,item[i].len,x);
		  ptr = BN_bn2dec(x);
	      printf("value:: %lf ETH (%s Wei)\n",V,ptr);
		  free(ptr);
		  break; 

	  case 6:
		  printf("data: 0x");
		  for(k=0;k<item[i].len;k++)
			  printf("%02X", 0xFF & item[i].data[k]);
		  printf("\n");
		  break; 

	  case 7:
		  printf("v: %d\n",0xFF & item[i].data[0]);
		  if (item[i].len != 1)
		  { printf("Recover (v) length error (length= %d)\n",item[i].len);
		    ferror=1;
		    i=11;
		  }
		  break;

      case 8:
		  printf("r: 0x");
		  for(k=0;k<item[i].len;k++)
			  printf("%02X", 0xFF & item[i].data[k]);
		  printf("(%d)\n",item[i].len);
		  break;

     case 9:
		  printf("s: 0x");
		  for(k=0;k<item[i].len;k++)
			  printf("%02X", 0xFF & item[i].data[k]);
		  printf("(%d)\n",item[i].len);
		  break;
	}

  }

if ( (ferror==0) && (fparse==1) )
{ nb=0;
  for(i=1;i<=6;i++)
  nb += item[i].len + item[i].lhead ;
  nb= encode_rlp(item[0].data,nb,0,tbuf2);
  printf("Raw Transaction: ");print(tbuf2,nb);

   rec = 0xFF & *item[7].data ;
   rec = rec-27; 
   
   x= BN_bin2bn(item[8].data,item[8].len,x);
   ptrr = BN_bn2hex(x);

   x= BN_bin2bn(item[9].data,item[9].len,x);
   ptrs = BN_bn2hex(x);

  nb= sha3_256(tbuf2,nb,digest);
  //print(digest,32);

  ptr= recover_signature(digest,32,ptrr,ptrs,rec,tbuf);
  if (ptr != NULL)
  {  printf("\nFrom: PublicKey= %s\n",ptr);
     fok=1;
     nb= Ascii2bin(ptr+2,tbuf2);
     nb= sha3_256(tbuf2,nb,digest);
	 printf("From: ETH Address= ");print(digest+12,20);
  }

  free (ptrs);
  free (ptrr);

}
    
  
  

  BN_free(x);
  return fok;

}





// testcase : 
// $./priv2pub 18E14A7B6A307F426A94F8114701E7C8E774E7F9A47E2C2035DB29A206321725
// 0450863AD64A87AE8A2FE83C1AF1A8403CB53F53E486D8511DAD8A04887E5B23522CD470243453A299FA9E77237716103ABC11A1DF38855ED6F2EE187E9C582BA6