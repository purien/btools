/* smartcard.c */
/* Copyright (C) 2017 Pascal Urien (pascal.urien@gmail.com)
 * All rights reserved.
 *
 * BTOOLS software is free for non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution.
 * 
 * Copyright remains Pascal Urien's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Pascal Urien should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes BTOOLS software written by
 *     Pascal Urien (pascal.urien@gmail.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY PASCAL URIEN ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */



#define _CRT_SECURE_NO_WARNINGS

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <winscard.h>
#include <time.h>
#include <sys/timeb.h>

#include "card.h"
#include "smartcard.h"
#include "pcscemulator.h"

extern  int Ascii2bin(char *data_in,char *data_out);

static char Reader_Buf[4096]   ;
static int  pr[MAX_READER]     ;
static int  Reader_Nb=0        ;



static LONG APDUTransmit(
  IN SCARDHANDLE hCard,  
  DWORD Ptcol,
  IN LPCBYTE request,
  IN DWORD Asize,
  IN OUT LPSCARD_IO_REQUEST pioRecvPci,
  OUT LPBYTE Response,
  IN OUT LPDWORD pRsize);

int GetPtcol(int session)
{ return ReaderDB[session].Ptcol;}


int send_apdu(int session, char *req, int offset, int length, char *resp, int resp_off)
{ char out[260]         ;
  char Response[260]    ;
  LONG stat             ;
  DWORD Rsize=260       ;

  memcpy(out,req + offset,length);
   
  stat = APDUTransmit(ReaderDB[session].hCard,ReaderDB[session].Ptcol,out,length,NULL,Response,&Rsize);

  if (stat == SCARD_S_SUCCESS)
  {memcpy(resp,Response,Rsize);
   return Rsize;
  }
  else
   return -1;
  
}


int StartCard(int i,int session, char *Aid)
{
ReaderDB[session].name = Reader_Buf + pr[i];

return StartCard2(i,Aid,NULL,&ReaderDB[session].hCard, &ReaderDB[session].hContext,&ReaderDB[session].Ptcol) ;
}


DetectAllCard(char *Aid) 
{ int i,k=0;
 
Reader_Nb= DetectAllReader();

for(i=0;i<Reader_Nb;i++)
{
if(StartCard2(i,Aid,NULL,&ReaderDB[k].hCard, &ReaderDB[k].hContext,&ReaderDB[k].Ptcol)>=0)
{ PCSC_Session_Close(&ReaderDB[k].hCard,&ReaderDB[k].hContext,&ReaderDB[k].Ptcol);
  k++;
}
}

return k;
}


int StartFirstCard(int session, char *Aid) 
{ int err,i,k=0;

for(i=0;i<Reader_Nb;i++)
{

err=StartCard2(i,Aid,NULL,&ReaderDB[session].hCard, &ReaderDB[session].hContext,&ReaderDB[session].Ptcol) ;

if (err <0) continue ;
if (ReaderDB[session].name != NULL) continue;

if (k == session)
{
ReaderDB[session].name = Reader_Buf + pr[i];
return(i);
}

else k++;


}

return(-1);

}



#define PSIZE 16

static LONG APDUTransmit(
  IN SCARDHANDLE hCard,  
  DWORD Ptcol,
  IN LPCBYTE request,
  IN DWORD Asize,
  IN OUT LPSCARD_IO_REQUEST pioRecvPci,
  OUT LPBYTE Response,
  IN OUT LPDWORD pRsize)
{ LONG v;
  int i;

  struct timeb timebuffer1;
  struct timeb timebuffer2;
  long t1,t2,dtm          ;

if (do_verbose)
{ printf("Tx: ");
  for(i=0;i<(int)Asize;i++)
  {	   if ( (i!=0) && (i%PSIZE == 0) ) printf("\n    ");
       printf("%2.2X ",request[i]);
  }
  printf("\n");
}

ftime(&timebuffer1);
if      ( Ptcol == 1) v=SCardTransmit2(hCard,SCARD_PCI_T0, request,Asize,pioRecvPci,Response,pRsize);
else if ( Ptcol == 2) v=SCardTransmit2(hCard,SCARD_PCI_T1, request,Asize,pioRecvPci,Response,pRsize); 
else                  v=SCardTransmit2(hCard,SCARD_PCI_RAW,request,Asize,pioRecvPci,Response,pRsize);         
ftime(&timebuffer2);

t1 =  (int)(timebuffer1.time % 3600)*1000 +   timebuffer1.millitm   ;
t2 =  (int)(timebuffer2.time % 3600)*1000 +   timebuffer2.millitm   ;
dtm = (t2-t1);
if (dtm <0) dtm += 3600000 ;
apdu_dtc += dtm;

if (do_verbose)
{ printf("Rx: ");
  for(i=0;i<(int)*pRsize;i++)
  {	  if ( (i!=0) && (i%PSIZE == 0) ) printf("\n    ");
      printf("%2.2X ",Response[i]);
  }
  printf("\n");
}

return(v);

}

void TxAPDU(char * apdu,SCARDCONTEXT *hCard,DWORD *Ptcol)
{ char buf[900],out[260];
  char Response[260]    ;
  int len          ;
  LONG stat        ;
  DWORD Rsize=260  ;

  strcpy(buf,apdu);
  len= Ascii2bin(buf,out);
  stat = APDUTransmit(*hCard,*Ptcol,out,len,NULL,Response,&Rsize);

  return ;
 
}

int GetReaderIndex(char *readername)
{ DWORD dwReaders;
  int i ;
  char *pname=Reader_Buf;
  dwReaders=sizeof(Reader_Buf);


  // ####################################
  // Step 0 Smartcard Readers List
  // ####################################

  SCardListReadersA2((IN SCARDCONTEXT)NULL,NULL,Reader_Buf,&dwReaders);
  
  Reader_Nb=0;

  pr[0]=0;
  while(strlen(pname) != 0)
  {  Reader_Nb++;
     pr[Reader_Nb] = 1+ pr[Reader_Nb-1] + (int)strlen(pname) ;
	 
	 pname += (1+strlen(pname));
  }

  for(i=0;i<Reader_Nb;i++)
  { if (strcmp(readername,Reader_Buf + pr[i]) == 0)
    return(i);
  }

  return(-1);
}



//====================================
// Detect the first reader with a
// smartcard inserted
// Returns the reader number 0...n-1
//====================================



int DetectReader(SCARDCONTEXT *hCard,SCARDCONTEXT *hContext,DWORD *Ptcol,char *Atr,int *Atrlen,char *readername)
{ DWORD dwReaders;
  DWORD dwScope= (DWORD)SCARD_SCOPE_SYSTEM  ;
  DWORD dwState                             ;
  LPCVOID pvReserved1=  (LPCVOID) NULL      ;
  LPCVOID pvReserved2=  (LPCVOID) NULL      ;
  LONG stat;

  int i ;
  char *pname=Reader_Buf;
  dwReaders=sizeof(Reader_Buf);

  if (readername == NULL)
  {

  // ####################################
  // Step 0 Smartcard Readers List
  // ####################################

  SCardListReadersA2((IN SCARDCONTEXT)NULL,NULL,Reader_Buf,&dwReaders);
  
  Reader_Nb=0;

  pr[0]=0;
  while(strlen(pname) != 0)
  {  Reader_Nb++;
     pr[Reader_Nb] = 1+ pr[Reader_Nb-1] + (int)strlen(pname) ;
	 pname += (1+strlen(pname));
  }


  // ##############################
  // Step 2 - PC/SC Initialization 
  // ##############################
  *hContext=(SCARDCONTEXT)NULL ;
  stat = SCardEstablishContext2(dwScope,pvReserved1,pvReserved2,hContext);
  if (stat  != SCARD_S_SUCCESS)
  
  return(-1); // Erreur PC/SC
 
  
  for(i=0;i<Reader_Nb;i++)
  {
  // #######################################
  // Step 2 - Smartcard insertion detection
  // #######################################
  *hCard=(SCARDCONTEXT)NULL ;
  stat = SCardConnectA2(*hContext,Reader_Buf + pr[i],
	                 (DWORD) SCARD_SHARE_SHARED,
	                 (DWORD)(SCARD_PROTOCOL_T0|SCARD_PROTOCOL_T1),
					 hCard,
					 Ptcol);

  if (stat == SCARD_S_SUCCESS)
  {
  // ##########################################
  // Step 3 - ATR and smartcard insertion test
  // ##########################################
   
   stat = SCardState2(*hCard,&dwState,Ptcol,Atr,Atrlen);

   // If no smartcard, goto next step 
   if ((stat != SCARD_S_SUCCESS) || (dwState == SCARD_ABSENT));
   else break; 

   if (*hCard != (SCARDCONTEXT)NULL) 
   SCardDisconnect2(*hCard,(DWORD)SCARD_LEAVE_CARD) ; 
   hCard=(SCARDCONTEXT)NULL ;
   }

   }   // Other Reader

   
  if (i== Reader_Nb) 
  {   if (*hContext != (SCARDCONTEXT)NULL)
      stat = SCardReleaseContext2(*hContext);
	  return(-1) ;
  }
  
  else return(pr[i])  ;

  }


  else  // readername
  
  {

  *hContext=(SCARDCONTEXT)NULL ;
  stat = SCardEstablishContext2(dwScope,pvReserved1,pvReserved2,hContext);
  if (stat  != SCARD_S_SUCCESS) return(-1); // PC/SC Error !!!
  
  *hCard=(SCARDCONTEXT)NULL ;
  stat = SCardConnectA2(*hContext,readername,
	                 (DWORD)SCARD_SHARE_SHARED,
	                 (DWORD)(SCARD_PROTOCOL_T0|SCARD_PROTOCOL_T1),
					  hCard,
					  Ptcol);


  if (stat == SCARD_S_SUCCESS)
  {
     
   stat = SCardState2(*hCard,&dwState,Ptcol,Atr,Atrlen);

   // If no smartcard, goto next step 
   if ((stat != SCARD_S_SUCCESS) || (dwState == SCARD_ABSENT))
   { SCardDisconnect2(*hCard,(DWORD)SCARD_LEAVE_CARD) ; 
     hCard=(SCARDCONTEXT)NULL ;
	 stat = SCardReleaseContext2(*hContext);
	 hContext =(SCARDCONTEXT)NULL ;
	 return(-1);
   }

   else
	   return(0);

  }
 
  }
return(-1);

}


//===========================
//   Opening PC/SC session
//===========================
int PCSC_Session_Open(SCARDCONTEXT * hCard,SCARDCONTEXT * hContext,DWORD *Ptcol,int CheckAtr,_INTERFACE *p)
{
  DWORD dwScope= (DWORD)SCARD_SCOPE_SYSTEM  ;
//  DWORD dwActiveProtocol ;
  LPCVOID pvReserved1=  (LPCVOID) NULL      ;
  LPCVOID pvReserved2=  (LPCVOID) NULL      ;
  LONG stat;
  char Response[512],request[512];
  int Rsize,Asize,ThisIndex=-1,i ;
  char Atr[256] ;
  DWORD Atrlen = sizeof(Atr) ;
  
   if (*hCard != (SCARDCONTEXT)NULL) 
   stat = SCardDisconnect2(*hCard,(DWORD)SCARD_LEAVE_CARD) ;

   if (*hContext != (SCARDCONTEXT)NULL)
   stat = SCardReleaseContext2(*hContext);

   // Sleep(1000);
  
   *hContext=(SCARDCONTEXT)NULL ;
   *hCard   =(SCARDCONTEXT)NULL ;

  if (DetectReader(hCard,hContext,Ptcol,Atr,&Atrlen,p->Reader_String) <0)
  { PCSC_Session_Close(hCard,hContext,Ptcol);
    return(-1); }  

  if (CheckAtr)
  { if (memcmp(Atr,p->Atr,p->AtrLen) !=0)
	{ 
	}
  }  

  
  if (p->AidLen)
  {
  request[0]=(char)0x00;request[1]=(char)0xA4;
  request[2]=(char)0x04;request[3]=(char)0x00;
  request[4]=0xFF & p->AidLen ;
  for(i=0;i<p->AidLen;i++) request[5+i]= p->AID[i];

  Asize= 5 + p->AidLen;
  
  Rsize= sizeof(Response);
  stat = APDUTransmit(*hCard,*Ptcol,request,Asize,NULL,Response,&Rsize);
  
  if (stat != SCARD_S_SUCCESS) 
  { PCSC_Session_Close(hCard,hContext,Ptcol);
    return (-3);} 
  

  // SW1 != 90    
   if ((Rsize < 2) || (Response[Rsize-2]  != (char) 0x90) ) 
   { PCSC_Session_Close(hCard,hContext,Ptcol);
     return(-4); } 

  }

  if (p->PinLen)
  {
  request[0]=(char)0x00;request[1]=(char)0x20;
  request[2]=(char)0x00;request[3]=(char)0x00;
  request[4]=0xFF & p->PinLen ;
  for(i=0;i<p->PinLen;i++) request[5+i]= p->Pin[i];

  Asize= 5 + p->PinLen;
  
  Rsize= sizeof(Response);
  stat = APDUTransmit(*hCard,*Ptcol,request,Asize,NULL,Response,&Rsize);
  
  if (stat != SCARD_S_SUCCESS) { PCSC_Session_Close(hCard,hContext,Ptcol);
  return (-5);} 
  

  // SW1 != 90    
   if ((Rsize < 2) || (Response[Rsize-2]  != (char) 0x90) ) 
   { PCSC_Session_Close(hCard,hContext,Ptcol);
     return(-6); } 

  }

  
  return(0);

   

}


int Is_PCSC_Session(SCARDCONTEXT *hCard,SCARDCONTEXT *hContext,DWORD *Ptcol)
{  char  bAtr[256];
   DWORD bAtrLen=sizeof(bAtr);
   DWORD dwState=0  ;
   LONG stat;	
   
   if (*hCard == (SCARDCONTEXT)NULL) return(0);
   
   stat = SCardState2(*hCard,&dwState,Ptcol,bAtr,&bAtrLen);

   if ((stat != SCARD_S_SUCCESS) || (dwState == SCARD_ABSENT))
   { PCSC_Session_Close(hCard,hContext,Ptcol); 
     return(0);}

   return(1);
			    

}

//===============================
//   Close PC/SC sessions
//===============================

int PCSC_Session_Close(SCARDCONTEXT * hCard,SCARDCONTEXT * hContext,DWORD *Ptcol)
{LONG stat ;
  
 if (*hCard != (SCARDCONTEXT)NULL) 
 stat = SCardDisconnect2(*hCard,(DWORD)SCARD_LEAVE_CARD) ;

 if (*hContext != (SCARDCONTEXT)NULL)
 stat = SCardReleaseContext2(*hContext);

 *hContext=(SCARDCONTEXT)NULL ;
 *hCard   =(SCARDCONTEXT)NULL ;
 *Ptcol=0;

 
 return(0);
}


int StartCard2(int index, char *AID, char *PIN,SCARDCONTEXT * hCard,SCARDCONTEXT * hContext,DWORD *Ptcol)
{
  char  line[1024]= {""};
  char  Atr[256];
  int   Atrlen=256 ;
  int i,rep ;
  _INTERFACE P ;

  memset((void *)&P,0,sizeof(_INTERFACE));
  
  // nb=DetectAllReader();

  rep=DetectReader(hCard,hContext,Ptcol,Atr,&Atrlen,Reader_Buf+pr[index]);
  
  if (rep<0) return(-1);
  
  if (do_verbose)
  printf("\nReader: %s\n",Reader_Buf+pr[index]);
  
  P.version = 1;
  strcpy(P.Reader_String,Reader_Buf+pr[index]);
  P.AtrLen = Atrlen ;
  for(i=0;i<Atrlen;i++) P.Atr[i]=Atr[i];

  if (PIN != NULL)
  {
  P.PinLen =  (int) strlen(PIN) ;
  memcpy(P.Pin,PIN,strlen(PIN)) ;
  }
  
  if (AID != NULL)
  P.AidLen =  Ascii2bin(AID,P.AID) ;
  
  sprintf(line,"T=%d ",(*Ptcol)-1);

  if (do_verbose)
  printf("%s - ",line);

  sprintf(line,"ATR: ");

  for(i=0;i<(int)Atrlen;i++) sprintf(&line[strlen(line)],"%2.2X ",0xFF & Atr[i]);
  
  if (do_verbose)
  printf("%s\n",line);	
  
  PCSC_Session_Close(hCard,hContext,Ptcol);
			   
  rep=PCSC_Session_Open(hCard,hContext,Ptcol,1,&P);
  if (rep<0) return(-2);
 	   
  
  return(0);
}

int DetectAllReader()
{ DWORD dwReaders;
  
  char *pname=Reader_Buf;
  dwReaders=sizeof(Reader_Buf);
 
  SCardListReadersA2((IN SCARDCONTEXT)NULL,NULL,Reader_Buf,&dwReaders);
  
  Reader_Nb=0;

  pr[0]=0;
  while(strlen(pname) != 0)
  {  Reader_Nb++;
     pr[Reader_Nb] = 1+ pr[Reader_Nb-1] + (int) strlen(pname) ;
	 pname += (1+strlen(pname));
  }

  return(Reader_Nb);
  }

int CloseCard(int k)
{   if (Is_PCSC_Session(&ReaderDB[k].hCard,&ReaderDB[k].hContext,&ReaderDB[k].Ptcol))
    { PCSC_Session_Close(&ReaderDB[k].hCard,&ReaderDB[k].hContext,&ReaderDB[k].Ptcol);
      ReaderDB[k].name = NULL;
    }
    else
		return 0;

   return 1;
}


