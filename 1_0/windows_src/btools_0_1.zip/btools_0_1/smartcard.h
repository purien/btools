/* 
 * API/eapcard.h 
 * Copyright (C) 2010 EtherTrust
 * All rights reserved.
 *
*/


#define ATRLEN           256
#define MAX_READER      2048
#define MAX_READER_NAME  256


typedef struct { int   version ;
                 int   PinLen  ;
				 char  Pin[9]  ;
				 char  Reader_String[MAX_READER_NAME] ;
                 char  Atr[ATRLEN];
                 int   AtrLen     ;
				 char  AID[16]    ;
				 int   AidLen     ;
				 int   mode       ;
} _INTERFACE;  



#define MAXREADER 64

typedef struct { SCARDCONTEXT  hCard   ;
				 SCARDCONTEXT  hContext;
				 DWORD Ptcol ;
				 char *name  ;
				 int index   ;
				}  ReaderList;


ReaderList ReaderDB[MAXREADER];


int PCSC_Session_Open(SCARDCONTEXT * hCard,SCARDCONTEXT * hContext,DWORD *Ptcol,int CheckAtr, _INTERFACE *p)  ;
int PCSC_Session_Close(SCARDCONTEXT * hCard,SCARDCONTEXT * hContext,DWORD *Ptcol) ;

int Is_PCSC_Session(SCARDCONTEXT * hCard,SCARDCONTEXT * hContext,DWORD *Ptcol)   ;

int StartCard2(int index,char *AID, char *PIN, SCARDCONTEXT * hCard,SCARDCONTEXT * hContext,DWORD *Ptcol);
