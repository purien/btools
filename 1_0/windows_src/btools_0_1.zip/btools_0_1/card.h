/* 
 * API/card.h 
 * Copyright (C) 2010 EtherTrust
 * All rights reserved.
 *
*/


int DetectAllCard(char *Aid);
int DetectAllReader();
int CloseCard(int k);

int GetReaderIndex(char *readername);

int StartCard(int reader_index,int session_index,char *aid)    ;
int StartFirstCard(int session,char *aid);
int GetPtcol(int session); 

int do_verbose ;
int apdu_dtc   ;

int send_apdu(int session,char *req, int offset, int length, char *resp, int resp_off);

#define CLA 0xA0

