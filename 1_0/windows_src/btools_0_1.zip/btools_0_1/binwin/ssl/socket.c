/* socket.c */
/* Copyright (C) 2017 Pascal Urien (pascal.urien@gmail.com)
 * All rights reserved.
 *
 * BTOOLS software is free for non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution.
 * 
 * Copyright remains Pascal Urien's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Pascal Urien should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes BTOOLS software written by
 *     Pascal Urien (pascal.urien@gmail.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY PASCAL URIEN ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#ifdef WIN32
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#endif

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/timeb.h>
#include <time.h>
#include <malloc.h>

#include <openssl/sha.h>

#ifndef WIN32
   #include <sys/types.h>
   #include <sys/socket.h>
   #include <netinet/in.h>
   #include <arpa/inet.h>
   #include <netdb.h>
   #include <unistd.h>
   #define DWORD long
#else
  #include <winsock.h>
#endif

static int ConnectServer(char * Server, unsigned short Port);
static int DeconnectServer(int client);
static int Recv(int s, char *buf, int size, int flags, int temps);

int DoTransaction(char *name, char *server, unsigned short port,int timeout);

extern int print(char *buf, int len);
extern int Ascii2bin(char *Data_In,char *data_out);

static char cacheHost[256];
static int  cacheIP=0     ;
char   default_IP[]= "127.0.0.1";


/*
C:\Users\Pascal>nslookup bitseed.xf2.org
Serveur :   cache1.service.virginmedia.net
Address:  194.168.4.100

R�ponse ne faisant pas autorit� :
Nom :    bitseed.xf2.org
Addresses:  68.48.214.241
          96.2.103.25
          50.177.196.160
          76.111.96.126
          173.69.49.106
          209.208.110.92
          85.214.90.1
          99.242.230.163
          162.243.194.210
          97.117.255.48
          24.52.35.44
          94.226.111.26
          198.38.93.227
*/
// Bitcoin cryptocurrency uses port 8333. (Bitcoin Testnet uses 18333 instead)


/*
Len: 100
71 11 01 00 

01 00 00 00 00 00 00 00 
7B 34 09 53 00 00 00 00

01 00 00 00 00 00 00 00 
00 00 00 00 00 00 00 00 00 00 FF FF
5B 79 0E 2D 
20 8D 

01 00 00 00 00 00 00 00 
00 00 00 00 00 00 00 00 00 00 FF FF
         !!!
0A 01 4C E1 
20 8D 
62 08 C9 35 8D A6 A9 00
0F 2F 53 61 74 6F 73 68 69 3A 30 2E 38 2E 36 2F 
65 AA 03 00
*/

static char mytest[] = 
"F9 BE B4 D9\
 76 65 72 73 69 6F 6E 00 00 00 00 00\
 64 00 00 00\
 3B 64 8D 5A\
 62 EA 00 00\
 01 00 00 00 00 00 00 00\
 11 B2 D0 50 00 00 00 00\
 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF FF 00 00 00 00 00 00\
 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF FF 00 00 00 00 00 00\
 3B 2E B3 5D 8C E6 17 65\
 0F 2F 53 61 74 6F 73 68 69 3A 30 2E 37 2E 32 2F\
 C0 3E 03 00" ;

 // If payload is empty, as in verack and getaddr messages, 
 // the checksum is always 0x5df6e0e2 (SHA256(SHA256(<empty string>)))


static char VERACK[] = 
 "F9 BE B4 D9\
  76 65 72 61 63 6B 00 00 00 00 00 00\
  00 00 00 00\
  5D F6 E0 E2";

int ftest=0;
// 66.90.137.8    98.144.159.4  FR "87.98.146.72"
// "66.90.137.89" reject non standard version
 // github "66.90.137.89"
//

// https://en.bitcoin.it/wiki/Protocol_documentation
// https://bitcoin.org/en/developer-reference#message-headers

// 52.4.156.236:18333 
// http://tpfaucet.appspot.com/
// Testnet3 is the current test network.

// https://www.biteasy.com/testnet/blocks
// https://www.blocktrail.com/tBTC

// dig online
//https://www.digwebinterface.com/
// Just use a testnet dns seeder.
// dig A testnet-seed.bitcoin.jonasschnelli.ch
// or
// dig A seed.tbtc.petertodd.org

int TestTransaction()
{

return DoTransaction("\\Users\\Pascal\\Documents\\Visual Studio 2005\\Projects\\binwin\\transaction777.bin", "35.187.74.199", (unsigned short)18333,1000);
//return DoTransaction("\\Users\\Pascal\\Documents\\Visual Studio 2005\\Projects\\binwin\\transaction99.bin", "5.178.68.215", (unsigned short)8333,1000);
}


int DoTransaction(char *name, char *server, unsigned short port,int timeout)
{  int s=0,i,nb,vi=0,vil=0;

struct { struct {
	     char magic[4];
         char command[12];
		 char len[4];
		 char checksum[4] ;
        } header;
	    union { struct {  char version [4]  ;
		                  char service [8]  ; 
						  char timestamp[8] ;

						  struct { char service[8];
						           char zero[10]  ;
								   char ff[2]     ;
								   char ip[4]     ;
								   char port[2]   ;
						         } 	addr_recv; // The network address of the node receiving this message

                          struct { char service[8];
						           char zero[10]  ;
								   char ff[2]     ;
								   char ip[4]     ;
								   char port[2]   ;
						         } 	addr_send; // The network address of the node emitting this message
                          char nonce[8];
						  char user_agent[16] ;
						  char start_height[4];
						  //char relay;   // optionnal
			          } version;
		       
		       char buf[2048];

		       } payload;
               
       } bmsg;

char digest[32]     ;
time_t ltime;
// struct tm* timeinfo ;
char *pt=NULL;
int r1,r2,version_len;
FILE *f= NULL;
char verack[24];
int more=0;
// 62 EA 00 00
// char myversion[4]={(char)0x7f,(char)0x11,(char)0x01,(char)0x00};
char myversion[4]= {(char)0x62,(char)0xea,(char)0x00,(char)0x00 };
char mymagic[4]=   {(char)0xF9,(char)0xBE,(char)0xB4,(char)0xD9 };
char mymagic_t[4]= {(char)0xFA,(char)0xBF,(char)0xB5,(char)0xDA }; 
char mymagic_t3[4]= {(char)0x0B, (char)0x11, (char)0x09, (char)0x07 }; 
int   lentrans  ;
long long t1=0, t2=0;
//char *ptrans=NULL;
 
   srand((int)(time((time_t)NULL)));   // should only be called once

   if (port == (unsigned short)18333 )
	   memmove(mymagic,mymagic_t3,4); 

   nb= Ascii2bin(VERACK,verack);
   memmove(verack,mymagic,4)   ;
   //SHA256("",0,digest) ;
   //SHA256(digest,32,digest);
   //for(i=0;i<4;i++) verack[i+20]= digest[i];
   //print(verack,24);


   //printf("Size of Version Message: %d\n", (int)sizeof(bmsg.payload.version) );
   version_len = (int)sizeof(bmsg.payload.version);

   memset(&bmsg,0,sizeof(bmsg));
   memset(&bmsg.payload.version,0,sizeof(bmsg.payload.version));

   // print((char *)&bmsg.payload.version,version_len);
   version_len -= 15; // User Agent length is zero

   memmove(bmsg.header.magic, mymagic,4);
   strcpy(bmsg.header.command,"version");

   bmsg.header.len[0] =    version_len  ;
   
   memmove(bmsg.payload.version.version,myversion,4);
  
   bmsg.payload.version.service[0]=(char)0x00 ; // 1= FULL NODE 0= TX only
  
   time(&ltime);                // local time
   //timeinfo = gmtime(&ltime); /* Convert to UTC */
   //ltime = mktime(timeinfo);  /* Store as unix timestamp */

   pt =(char *)&ltime;
   for(i=0;i<8;i++) bmsg.payload.version.timestamp[i]=*(pt+i);
  
   memmove(bmsg.payload.version.addr_recv.service,bmsg.payload.version.service,(int)sizeof(bmsg.payload.version.service));
   
   bmsg.payload.version.addr_recv.ff[0]=(char)0xff ;
   bmsg.payload.version.addr_recv.ff[1]=(char)0xff ;
   
   bmsg.payload.version.addr_recv.ip[0]= (char)127 ;
   bmsg.payload.version.addr_recv.ip[1]= (char)0   ;
   bmsg.payload.version.addr_recv.ip[2]= (char)0   ;
   bmsg.payload.version.addr_recv.ip[3]= (char)1   ;

   bmsg.payload.version.addr_recv.port[0]= (char) 0xff & (port>>8); 
   bmsg.payload.version.addr_recv.port[1]= (char) 0xff & port ; 

   memmove(&bmsg.payload.version.addr_send,&bmsg.payload.version.addr_recv,sizeof(bmsg.payload.version.addr_recv));

   bmsg.payload.version.addr_send.ip[0]= (char)127 ;
   bmsg.payload.version.addr_send.ip[1]= (char)0   ;
   bmsg.payload.version.addr_send.ip[2]= (char)0   ;
   bmsg.payload.version.addr_send.ip[3]= (char)1   ;

   r1 = rand(); r2 = rand();
 
   memmove(&bmsg.payload.version.nonce[0],&r1,4);
   memmove(&bmsg.payload.version.nonce[4],&r2,4);

   
   // bmsg.payload.version.user_agent[0]=(char)15;
   // strcpy(&bmsg.payload.version.user_agent[1],"/Satoshi:0.8.6/");
   
   // The last element in the Version payload is Block start height. 
   // This is the height of the latest block in our database
   // 0x0003aa65 = 240229

   
   SHA256((unsigned char *)&bmsg.payload.version,version_len,digest) ;
   SHA256(digest,32,digest);
   
   for(i=0;i<4;i++) bmsg.header.checksum[i]= digest[i];

   // print((char *)&bmsg,(int)sizeof(bmsg.header)+version_len);
   // print(digest,32);

   if (ftest)
   {
   nb= Ascii2bin(mytest,(char *)&bmsg);
   print((char *)&bmsg,nb);
   SHA256((unsigned char *)&bmsg.payload.version,(int)sizeof(bmsg.payload.version),digest) ;
   SHA256(digest,32,digest);
   //3B 64 8D 5A
   for(i=0;i<4;i++) bmsg.header.checksum[i]= digest[i];
   print(bmsg.header.checksum,4);
   return (0);
   }


   printf("Connecting to %s:%u\n",server,port);
   s = ConnectServer(server, port);
   if (s <=0) return -1           ;
  
   
   // Send  version message
   printf("sending version message\n");
   nb = send(s,(char*)&bmsg,(int)sizeof(bmsg.header)+version_len,0);
   if (nb <=0)
   { DeconnectServer(s);
     return -1;
   }
  
   more=2;
   while(more != 0)
   {
   nb= Recv(s,(char*)&bmsg,(int)sizeof(bmsg.header),0,10);
   if (nb <=0)
   { DeconnectServer(s);
     return -1;
   }
   
   nb = (0xff & (int)bmsg.header.len[1]) ;
   nb = (nb << 8) & 0xFF00;
   nb += (0xff & (int)bmsg.header.len[0]);

   printf("receiving message: %s (length: %d)\n",bmsg.header.command,nb);
   
   if (strcmp(bmsg.header.command,"verack")==0)
   more -=1 ;
  
   if (nb > 0)
   {
     nb= Recv(s,(char*)&bmsg.payload.buf,nb,0,10);
     if (nb > 0) 
     { // print((char*)&bmsg, nb+(int)sizeof(bmsg.header));
     }
	 else
     { DeconnectServer(s);
       return -1;
     }
    }


    if (strcmp(bmsg.header.command,"version") == 0)
	{ 
	   more -=1 ;
	   printf("sending message verack\n");
	   nb = send(s,verack,(int)sizeof(verack),0);
       if (nb <=0)
       { DeconnectServer(s);
         return -1;
       }

     }



   }

 
 
   if (name != NULL)
   {
   f =fopen(name,"rb");

   if (f == NULL)
   { DeconnectServer(s);
     return -1;
   }
    
   memset(&bmsg,0,sizeof(bmsg));

   nb = (int)fread(bmsg.payload.buf,(int)1,(int)sizeof(bmsg.payload.buf),f);
   fclose(f);
 
   memmove(bmsg.header.magic,mymagic,4);
   strcpy(bmsg.header.command,"tx")    ;

   bmsg.header.len[0] =    (char)(nb & 0xFF )       ;
   bmsg.header.len[1] =    (char)((nb>>8) & 0xFF )  ;
  
   SHA256(bmsg.payload.buf,nb,digest) ;
   SHA256(digest,32,digest)           ;
   
   printf("Sending TxId: ");
   for(i=0;i<32;i++)printf("%02X", 0xff & digest[31-i]);
   printf("\n");
   
   for(i=0;i<4;i++) bmsg.header.checksum[i]= digest[i];
   
   lentrans = (int)sizeof(bmsg.header)+nb ;

   // ptrans = malloc(lentrans);
   // memmove(ptrans,(char *)&bmsg,lentrans);

   //print((char *)&bmsg,lentrans);

   //////////////////////////////////////
   more=1;
   //////////////////////////////////////
   }
	  
 
  if (more)
   {  // Send  transaction Message
      printf("sending transaction message\n");
	  #ifndef WIN32
	  usleep(100000); // usleep(microseconds);
      #else
	  Sleep(100);
      #endif
	  
      nb = send(s,(char *)&bmsg,lentrans,0);
      
	  #ifndef WIN32
	  usleep(100000);
      #else
	  Sleep(100);
      #endif

	  //free(ptrans);

      if (nb <=0)
      { DeconnectServer(s);
        return -1;
      }
      
	  more=0;
	 
   }
  
   printf("waiting...\n");

   time(&ltime); 
   t1 = (long long)ltime;

   
   while(1)
   {  time(&ltime); 
	  t2 = (long long)ltime;
      t2 = t2-t1;
	 
	  if (((int)t2) >= timeout)
		  break;

   memset((char*)&bmsg,0,sizeof(bmsg));

   nb= Recv(s,(char*)&bmsg,(int)sizeof(bmsg.header),0,60);
   if (nb <=0)
   { DeconnectServer(s);
     return -1;
   }
   
   nb = (0xff & (int)bmsg.header.len[1]) ;
   nb = (nb << 8) & 0xFF00;
   nb += (0xff & (int)bmsg.header.len[0]) ;

   printf("message: %s (length: %d)\n",bmsg.header.command,nb);

   if (nb >0)
   {
     nb= Recv(s,(char*)&bmsg.payload.buf,nb,0,60);
     if (nb <=0)
     { DeconnectServer(s);
       return -1;
     }
   }

   if (strcmp(bmsg.header.command,"ping") == 0)
   { strcpy(bmsg.header.command,"pong");
     nb = nb + (int)sizeof(bmsg.header);
     printf("sending pong message\n");
     nb = send(s,(char*)&bmsg,nb,0);
     if (nb <=0)
     { DeconnectServer(s);
       return -1;
	 }
    }

   else if (strcmp(bmsg.header.command,"reject") == 0)
   {
   vil= 0xff & bmsg.payload.buf[0];
   printf("Type of rejected message: "); 
   for(i=0;i<vil;i++)
   printf("%c",bmsg.payload.buf[1+i]);
   printf("\n");

   switch (bmsg.payload.buf[1+vil]) // reason
   {
   case (char)0x01:  printf("Reason code: REJECT_MALFORMED\n");break; 
   case (char)0x10:  printf("Reason code: REJECT_INVALID\n");break;   
   case (char)0x11:  printf("Reason code: REJECT_OBSOLETE\n");break;   
   case (char)0x12:  printf("Reason code: REJECT_DUPLICATE\n");break;  
   case (char)0x40:  printf("Reason code: REJECT_NONSTANDARD\n");break;     
   case (char)0x41:  printf("Reason code: REJECT_DUST\n");break;   
   case (char)0x42:  printf("Reason code: REJECT_INSUFFICIENTFEE\n");break;  
   case (char)0x43:  printf("Reason code: REJECT_CHECKPOINT\n");break;  
   }

   vi = 0xff & bmsg.payload.buf[2+vil];
   for(i=0;i<vi;i++) 
	   printf("%c",bmsg.payload.buf[3+vil+i]);
   printf("\n");

   nb = (0xff & (int)bmsg.header.len[1]) ;
   nb = (nb << 8) & 0xFF00;
   nb += (0xff & (int)bmsg.header.len[0]);

   for(i=0;i< nb-3-vil-vi; i++)
	   printf("%02.2X",0xff & bmsg.payload.buf[nb-1 - i]) ;
   printf("\n");

   }

   }


   
   DeconnectServer(s);
   return(0);

} 

static int Recv(int s, char *buf, int size, int flags,int temps)
{ int err=0,len=0;
  struct timeval timeout ; 
  fd_set a_fd_set ;
 
  timeout.tv_sec  = temps ; // secondes
  timeout.tv_usec = 0L    ;

  while(1)
	{  FD_ZERO(&a_fd_set)  ;
	   FD_SET(s,&a_fd_set) ;
	   err = select (1+s,&a_fd_set,NULL,NULL,&timeout); 
      
	   if (FD_ISSET (s, &a_fd_set))  // something received 
	   {  err= recv(s,&buf[len],size-len,flags);
	      if (err <=0) break ;
	   }
	   else // timeout
	   { return -1;
	   }

	   len+=err;
	   if (len >= size)  break;
	}

    buf[len]=0 ;
	return len ;
}


static int SetConnectAddress(struct sockaddr_in *sin,unsigned short port,char *host)
{ 
 struct hostent *phe ;
	 
 sin->sin_family      = AF_INET    ;
 sin->sin_port        = htons(port);
 	 
 if ( (cacheIP !=0) && (strcmp(host,cacheHost)==0) )
 {  sin->sin_addr.s_addr = cacheIP;
 }
 
 else
 {
 sin->sin_addr.s_addr = inet_addr (host);
 cacheIP=0;
 cacheHost[0]=0;

 if (sin->sin_addr.s_addr == INADDR_NONE)
 {
	  phe = gethostbyname (host);
	  if (phe == NULL) return(0);
      
      else     
      memcpy(&(sin->sin_addr),phe->h_addr,4);
	  
	  if (sin->sin_addr.s_addr == INADDR_NONE)
	  return(0); 
	  
 }

 cacheIP= sin->sin_addr.s_addr ;
 strcpy(cacheHost,host);

 }
return(1);
 
}

static int ConnectServer(char * Server, unsigned short Port)
{
	struct sockaddr_in sin,csin   ; 
	int  err, namelen;
	int client;  
	
	
    client = (int) socket (AF_INET,SOCK_STREAM,0); 
 
	csin.sin_family = AF_INET   ;  
    csin.sin_port   = 0 ;  
    csin.sin_addr.s_addr =  INADDR_ANY;  
 
    err = bind (client,(struct sockaddr *) &csin, sizeof (csin));	
	if (err != 0)
	{ printf("Socket Bind Error !!!\n");
	  return 0;
	}

    namelen = sizeof(csin);
    err = getsockname(client, (struct sockaddr *) &csin, &namelen);
 
    sin.sin_family = AF_INET   ;  
    sin.sin_port = htons(Port) ;  
    sin.sin_addr.s_addr =  inet_addr(default_IP) ;


   if (!SetConnectAddress(&sin,(unsigned short)Port,Server))
   {
	   printf("DNS error for Server...\n");
	   return -1;
   }

    err= connect(client,(struct sockaddr *) &sin,sizeof(struct sockaddr) );

	if (err != 0)
	{ printf("Connection to Server Failed !!!\n");
	  return 0;
	}
    
    return client;

}
  
static int DeconnectServer(int client)
{ 
  shutdown(client,2) ;
  #ifndef WIN32
  close(client);
  #else
  closesocket(client);
  #endif

  return (0);

}
  




