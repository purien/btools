/* code58.c */
/* Copyright (C) 2017 Pascal Urien (pascal.urien@gmail.com)
 * All rights reserved.
 *
 * BTOOLS software is free for non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution.
 * 
 * Copyright remains Pascal Urien's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Pascal Urien should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes BTOOLS software written by
 *     Pascal Urien (pascal.urien@gmail.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY PASCAL URIEN ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS 
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

/* Converted to C by Rusty Russell, based on bitcoin source: */
// Copyright (c) 2009-2010 Satoshi Nakamoto
// Copyright (c) 2009-2012 The Bitcoin Developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.


#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <openssl/bn.h>
#include <openssl/ripemd.h>
#include <openssl/obj_mac.h>
#include <openssl/sha.h>

typedef unsigned char u8;
//typedef int bool;
#define true  1
#define false 0


extern int print(char *buf, int len);


static const char enc_16[] = "0123456789abcdef";
static const char enc_58[] = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

struct protocol_double_sha {
	u8 sha[SHA256_DIGEST_LENGTH /* 32 */ ];
};


void double_sha_of(struct protocol_double_sha *sha, const void *p, size_t len)
{   char digest[32]  ;
	
    SHA256((char *)p,(int)len,digest);
	SHA256(digest,32,sha->sha);
}




static char encode_char(unsigned long val, const char *enc)
{
	assert(val < strlen(enc));
	return enc[val];
}

static int decode_char(char c, const char *enc)
{
	const char *pos = strchr(enc, c);
	if (!pos)
		return -1;
	return (int)(pos - enc);
}




/*
 * Encode a byte sequence as a base58-encoded string.  This is a bit
 * weird: returns pointer into buf (or NULL if wouldn't fit).
 */

char *encode_base58(char *buf, size_t buflen,const u8 *data, size_t data_len)
{
	char *p;
	BIGNUM bn;

	/* Convert to a bignum. */
	BN_init(&bn);
	BN_bin2bn(data, (int)data_len, &bn);

	/* Add NUL terminator */
	if (!buflen) {
		p = NULL;
		goto out;
	}
	p = buf + buflen;
	*(--p) = '\0';

	/* Fill from the back, using a series of divides. */
	while (!BN_is_zero(&bn)) {
		int rem = BN_div_word(&bn, 58);
		if (--p < buf) {
			p = NULL;
			goto out;
		}
		*p = encode_char(rem, enc_58);
	}

	/* Now, this is really weird.  We pad with zeroes, but not at
	 * base 58, but in terms of zero bytes.  This means that some
	 * encodings are shorter than others! */
	while (data_len && *data == '\0') {
		if (--p < buf) {
			p = NULL;
			goto out;
		}
		*p = encode_char(0, enc_58);
		data_len--;
		data++;
	}

out:
	BN_free(&bn);
	return p;
}

// ToDo
char tolower(char c)
{
	return c;
}

/*
 * Decode a base_n-encoded string into a byte sequence.
 */
int raw_decode_base_n(BIGNUM *bn, const char *src, size_t len, int base)
{
	const char *enc;
    int val;

	BN_zero(bn);

	assert(base == 16 || base == 58);
	switch (base) {
	case 16:
		enc = enc_16;
		break;
	case 58:
		enc = enc_58;
		break;
	}

	while (len) {
		char current = *src;

		if (base == 16)
			current = tolower(current);	/* TODO: Not in ccan. */

		val = decode_char(current, enc);
		if (val < 0) {
			BN_free(bn);
			return false;
		}
		BN_mul_word(bn, base);
		BN_add_word(bn, val);
		src++;
		len--;
	}

	return true;
}

/*
 * Decode a base58-encoded string into a byte sequence.
 */
int raw_decode_base58(BIGNUM *bn, const char *src, size_t len)
{
	return raw_decode_base_n(bn, src, len, 58);
}

void base58_get_checksum(u8 csum[4], const u8 buf[], size_t buflen)
{
	struct protocol_double_sha sha_result;

	/* Form checksum, using double SHA2 (as per bitcoin standard) */
	double_sha_of(&sha_result, buf, buflen);

	/* Use first four bytes of that as the checksum. */
	memcpy(csum, sha_result.sha, 4);
}


extern unsigned char *GetPubKey(char *priv);
extern int Ascii2bin(char *Data_In,char *data_out);

int CheckPriv(char * buf, int len);



int Check_BTC_Adr(char *buf, int len)
{
BIGNUM *bn;
  int err,size;
  char * bbuf=NULL;
  char hsum[4];
  int i;

  bn = BN_new();
  err=  raw_decode_base_n(bn, buf, (size_t) len, 58);
  
  size= BN_num_bytes(bn)    ;
  
  bbuf= malloc((size_t)25);
  memset(bbuf,0,25);

  err = BN_bn2bin(bn, &bbuf[25-size]) ;

  //print(bbuf,25);

  base58_get_checksum((u8 *)hsum, bbuf, (size_t) (25-4) );

  //print(hsum,4);

  if (memcmp(hsum,bbuf+(25-4),4) == 0)
	  printf("Double SHA2 Check OK\n");
  else
	  printf("Checksum Error !!!\n");

  printf("ID: %2.2X\n",0xff & bbuf[0]);
  printf("Hash160: ");
  for(i=0;i<20;i++) printf("%02.2X", 0xff & bbuf[i+1]);
  printf("\n");

  free(bbuf);
  BN_free(bn);

  return err;


}







int Decode58(char *buf, int len, char *hex)
{ BIGNUM *bn;
  int err,size;
  char * bbuf=NULL;
  char hsum[4];


  bn = BN_new();
  err=  raw_decode_base_n(bn, buf, (size_t) len, 58);
  
  hex = BN_bn2hex(bn); // The string must be freed later using OPENSSL_free()

  printf("%s\n",hex);

  size= BN_num_bytes(bn)    ;
  bbuf= malloc((size_t)size);
  err = BN_bn2bin(bn, bbuf) ;

  print(bbuf,size);

  base58_get_checksum((u8 *)hsum, bbuf, (size_t) err-4);

  print(hsum,4);

  if (memcmp(hsum,bbuf+(err-4),4) == 0)
	  printf("Double SHA2 Check OK\n");

  free(bbuf);

  BN_free(bn);

  return err;


}

extern unsigned char *GetPubKey(char *priv);
extern int Ascii2bin(char *Data_In,char *data_out);
int CheckWIF(char * buf, int len);


int Generate_BTC_Adr_From_Pubkey(char *pub, char ID)
{
 unsigned char *pub_hex = NULL;
 char *pubkey = NULL  ;
 char buf[256]  ;
 int keylen;
 char digest[32]   ;
 char digest2[32]  ;
 char abuf[256];
 char *pbuf;
 int i;
 
 pubkey = buf;
 
 printf("PublicKey: %s\n",pub);
 keylen= Ascii2bin(pub,pubkey);

 SHA256(pubkey,keylen,digest) ;
 RIPEMD160(digest,32,digest+1);

 printf("Hash160: ");
 for(i=0;i<20;i++) printf("%2.2X",0xff & *(digest+1+i) );
 printf("\n");

 // ID =00 or 6F
 digest[0]=ID;

 SHA256(digest,21,digest2) ;
 SHA256(digest2,32,digest2);

 memcpy(digest+21,digest2,4);
 
 pbuf= encode_base58(abuf, sizeof(abuf),digest,25);
 printf("BTC-Adr: %s\n",pbuf);

 Check_BTC_Adr(pbuf,(int)strlen(pbuf));
 //=====================================

 
 return 0;

}


int Generate_BTC_Adr_From_Privkey(char *priv, char ID)
{
 unsigned char *pub_hex = NULL;
 char *pubkey = NULL  ;
 char buf[256]  ;
 int keylen;
 char digest[32]   ;
 char digest2[32]  ;
 char abuf[256];
 char *pbuf;
 int i;
 BIGNUM *bn;
 char *privkey=NULL ;

 privkey= buf;
 pubkey = buf;
 

pub_hex = GetPubKey(priv);

bn = BN_new();

 printf("PublicKey: %s\n",pub_hex);
 keylen= Ascii2bin(pub_hex,pubkey);

 SHA256(pubkey,keylen,digest) ;
 RIPEMD160(digest,32,digest+1);

 printf("Hash160: ");
 for(i=0;i<20;i++) printf("%2.2X",0xff & *(digest+1+i) );
 printf("\n");

 // ID =00 or 6F
 digest[0]=ID;

 SHA256(digest,21,digest2) ;
 SHA256(digest2,32,digest2);

 memcpy(digest+21,digest2,4);
 
 pbuf= encode_base58(abuf, sizeof(abuf),digest,25);
 printf("BTC-Adr: %s\n",pbuf);

 Check_BTC_Adr(pbuf,(int)strlen(pbuf));

 BN_free(bn)  ; 
 free(pub_hex);  


 //=====================================

 memset(buf,0,sizeof(buf));

 if (ID == (char)0)
	 buf[0]=(char)0x80 ;
 else
     buf[0]=(char)0xef;

 
 keylen= Ascii2bin(priv,buf+1);
 
 SHA256(buf,keylen+1,digest)  ;
 SHA256(digest,32,digest)     ;
 memmove(buf+1+keylen,digest,4);

 pbuf= encode_base58(abuf, sizeof(abuf),buf,1+keylen+4);
 printf("BTC-WIF: %s\n",pbuf);

 //printf("\n");
 //CheckWIF(pbuf,(int)strlen(pbuf));

 return 0;

}


int CheckWIF(char * buf, int len)
{ BIGNUM *bn;
  int err,size;
  char * bbuf=NULL;
  char hsum[4];
  char tbuf[256];
  int v,i;
  char *hex = NULL;

  bn = BN_new();
  err=  raw_decode_base_n(bn, buf, (size_t) len, 58);
  
  hex = BN_bn2hex(bn); // The string must be freed later using OPENSSL_free()

  // printf("%s\n",hex);

  size= BN_num_bytes(bn);
  bbuf= malloc((size_t)size);
  err = BN_bn2bin(bn, bbuf);

  // print(bbuf,size);

  base58_get_checksum((u8 *)hsum, bbuf, (size_t) err-4);

  // print(hsum,4);

  if (memcmp(hsum,bbuf+(err-4),4) == 0)
	  printf("Double SHA2 Checksum OK\n");

  
  printf("ID: %02.2X\n", 0xff & bbuf[0]);
  
  tbuf[0]=0;
  bbuf[0]=0;
  memset(tbuf,0,(int)sizeof(tbuf));
    
  for (i=1;i<= (err-5);i++)
  {   v = 0xff & bbuf[i] ;
	  sprintf(&tbuf[strlen(tbuf)],"%02X",v);
  }

  
  printf("PrivateKey %02d: %s\n", strlen(tbuf), tbuf);
 
  free(bbuf);
  BN_free(bn);
  return err;


}

char * DecodeWIF(char * buf)
{ BIGNUM *bn;
  int err,size;
  char * bbuf=NULL;
  char hsum[4];
  static char tbuf[256];
  int v,i;
  char *hex = NULL;

  bn = BN_new();
  err=  raw_decode_base_n(bn, buf, (size_t) strlen(buf), 58);
  
  hex = BN_bn2hex(bn); // The string must be freed later using OPENSSL_free()

  // printf("%s\n",hex);

  size= BN_num_bytes(bn);
  bbuf= malloc((size_t)size);
  err = BN_bn2bin(bn, bbuf);

  // print(bbuf,size);

  base58_get_checksum((u8 *)hsum, bbuf, (size_t) err-4);

  // print(hsum,4);

  if (memcmp(hsum,bbuf+(err-4),4) != 0)
	  return NULL;

  tbuf[0]=0;
  bbuf[0]=0;
  memset(tbuf,0,(int)sizeof(tbuf));
    
  for (i=1;i<= (err-5);i++)
  {   v = 0xff & bbuf[i] ;
	  sprintf(&tbuf[strlen(tbuf)],"%02X",v);
  }

  
  free(bbuf) ;
  BN_free(bn);

  return tbuf;
}


char * Decode_BTC_Adr(char *buf)
{
BIGNUM *bn;
  int err,size;
  char * bbuf=NULL;
  char hsum[4];
  int i;
  static char hash160[21];

  bn = BN_new();
  err=  raw_decode_base_n(bn, buf, (size_t) strlen(buf), 58);
  
  size= BN_num_bytes(bn)    ;
  
  bbuf= malloc((size_t)25);
  memset(bbuf,0,25);

  err = BN_bn2bin(bn, &bbuf[25-size]) ;

  //print(bbuf,25);

  base58_get_checksum((u8 *)hsum, bbuf, (size_t) (25-4) );

  //print(hsum,4);

  if (memcmp(hsum,bbuf+(25-4),4) != 0)
	  return NULL;

  hash160[0]=0;

  for(i=0;i<20;i++) sprintf(hash160+strlen(hash160),"%02.2X", 0xff & bbuf[i+1]);
   
  free(bbuf);
  BN_free(bn);

  return hash160;


}

int B58_to_hexa(char *buf)
{ BIGNUM *bn;
  int err ;
  char * hex=NULL;
 
  bn = BN_new();
  err=  raw_decode_base_n(bn, buf, strlen(buf), 58);
  
  hex = BN_bn2hex(bn); // The string must be freed later using OPENSSL_free()
  printf("%s\n",hex) ;

  BN_free(bn);
  free(hex);

  return err;

}

extern int Ascii2bin(char *Data_In,char *data_out);

int hexa_to_B58(char *data)
{ char buf[256];
  char bin[256];
  int nb;
  char *hexa=NULL;
   
  nb = Ascii2bin(data,bin);
  hexa = encode_base58(buf, sizeof(buf),(const u8 *)bin,nb);

  printf("%s\n",hexa);

  return 0;

 
}